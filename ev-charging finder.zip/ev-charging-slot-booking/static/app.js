/* Front end for the EV charging slot booking & issue tracking app.
   Plain JavaScript, no build step. Sections: helpers, login, app start-up,
   stations + Google Map, booking, my bookings, payments, issues, history. */
"use strict";

// ------------------------------------------------------------ helpers
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const inr = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pad = (n) => String(n).padStart(2, "0");
const hms = (s) => { s = Math.max(0, Math.floor(s)); return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`; };
const mmss = (s) => { s = Math.max(0, Math.floor(s)); return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`; };
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function niceDate(str) { // "2026-10-09 18:30" -> "9 Oct 2026, 18:30"
  const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}:\d{2})/.exec(str || "");
  return m ? `${Number(m[3])} ${MONTHS[Number(m[2]) - 1]} ${m[1]}, ${m[4]}` : (str || "");
}

const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked, ignore */ } },
};

async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || (opts.body ? "POST" : "GET"),
    headers: { "Content-Type": "application/json", "X-Requested-With": "fetch" },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: "same-origin",
  });
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (res.status === 401 && !opts.quiet401) { loggedOut("Your session ended. Please log in again."); }
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function toast(msg, kind = "") {
  const t = document.createElement("div");
  t.className = "toast " + kind;
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 350); }, 4500);
}

function haversine(a, b) {
  const R = 6371, rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b[0] - a[0]), dLng = rad(b[1] - a[1]);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

// ------------------------------------------------------------ state
const FAST_KW = 60; // 60 kW and above counts as a fast charger
const S = {
  user: null, cfg: null, cities: [], stations: [], byId: {},
  slots: {}, sessions: [], lastEvent: null,
  city: store.get("ev_city", "Hyderabad"),
  filter: "all", sort: "best", query: "",
  favs: new Set(store.get("ev_favs", [])),
  userPos: null, tab: "stations",
  drawerId: null, slotIdx: null,
  form: Object.assign({ name: "", vehicle: "", model: "Tata Nexon EV", capacity: 40, start: 20, target: 80 }, store.get("ev_form", {})),
  sigList: "", sigSessions: "", sigDrawer: "",
  online: true, polling: 0, bound: false,
  issues: [], issueScope: "mine", issueMeta: null,
  account: null, sigAcct: "",
};

function resetState() {
  S.slots = {}; S.sessions = []; S.lastEvent = null; S.drawerId = null; S.slotIdx = null;
  S.sigList = ""; S.sigSessions = ""; S.sigDrawer = ""; S.issues = []; S.issueScope = "mine"; S.account = null; S.sigAcct = "";
  S.polling++; // stops the old poll loop
}

// ------------------------------------------------------------ login
const A = {
  identifier: "", timer: null,
  show(step) {
    $("#auth").hidden = false; $("#app").hidden = true;
    ["Id", "Otp", "Name"].forEach((n) => ($("#step" + n).hidden = n !== step));
    const focus = { Id: "#identifier", Otp: "#otp", Name: "#fullName" }[step];
    setTimeout(() => $(focus).focus(), 30);
  },
  startCountdown(sec) {
    clearInterval(A.timer);
    const btn = $("#resendBtn");
    let left = sec;
    const tick = () => {
      btn.disabled = left > 0;
      btn.textContent = left > 0 ? `Resend code in ${left}s` : "Resend code";
      if (left-- <= 0) clearInterval(A.timer);
    };
    tick(); A.timer = setInterval(tick, 1000);
  },
};

async function requestOtp(identifier) {
  $("#idError").textContent = ""; $("#otpError").textContent = "";
  const btn = $("#sendBtn");
  btn.disabled = true; btn.textContent = "Sending...";
  try {
    const r = await api("/api/auth/request-otp", { body: { identifier }, quiet401: true });
    A.identifier = r.identifier;
    $("#sentTo").textContent = r.to;
    const demo = $("#demoOtp");
    if (r.channel === "demo") {
      demo.hidden = false;
      demo.innerHTML = r.dev_otp
        ? `Demo mode: no SMS or email service is set up, so the code is shown here instead.<br>Your code: <b>${esc(r.dev_otp)}</b>`
        : "Demo mode: no SMS or email service is set up. Look for the code in the terminal where app.py is running.";
    } else demo.hidden = true;
    $("#otp").value = "";
    A.show("Otp");
    A.startCountdown(r.resend_in);
  } catch (e) {
    ($("#stepOtp").hidden ? $("#idError") : $("#otpError")).textContent = e.message;
  } finally {
    btn.disabled = false; btn.textContent = "Send OTP";
  }
}

function bindAuth() {
  $("#stepId").addEventListener("submit", (e) => { e.preventDefault(); requestOtp($("#identifier").value); });
  $("#resendBtn").onclick = () => requestOtp(A.identifier);
  $("#changeIdBtn").onclick = () => { clearInterval(A.timer); A.show("Id"); };
  $("#otp").addEventListener("input", (e) => {
    e.target.value = e.target.value.replace(/\D/g, "").slice(0, 6);
    if (e.target.value.length === 6) $("#stepOtp").requestSubmit();
  });
  $("#stepOtp").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("#verifyBtn");
    if (btn.disabled) return;
    btn.disabled = true; btn.textContent = "Checking...";
    $("#otpError").textContent = "";
    try {
      const r = await api("/api/auth/verify-otp", { body: { identifier: A.identifier, otp: $("#otp").value }, quiet401: true });
      S.user = r.user;
      if (r.needs_name) { $("#fullName").value = ""; A.show("Name"); } else await enterApp();
    } catch (er) {
      $("#otpError").textContent = er.message; $("#otp").select();
    } finally { btn.disabled = false; btn.textContent = "Verify and log in"; }
  });
  $("#stepName").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      const r = await api("/api/auth/profile", { body: { name: $("#fullName").value } });
      S.user = r.user;
      await enterApp();
    } catch (er) { $("#nameError").textContent = er.message; }
  });
}

function loggedOut(message) {
  if (!S.user) return;
  S.user = null;
  resetState();
  closeDrawer(); closePay(); closeIssueModal();
  A.show("Id");
  if (message) $("#idError").textContent = message;
}

async function logout() {
  try { await api("/api/auth/logout", { method: "POST", body: {}, quiet401: true }); } catch { /* already gone */ }
  loggedOut();
}

// ------------------------------------------------------------ start-up
async function start() {
  bindAuth();
  try { const c = await api("/api/config", { quiet401: true }); document.title = c.app_name; } catch { /* keep the static title */ }
  try {
    const me = await api("/api/auth/me", { quiet401: true });
    S.user = me.user;
    if (me.needs_name) A.show("Name"); else await enterApp();
  } catch {
    A.show("Id");
  }
  document.body.classList.remove("is-loading");
}

async function enterApp() {
  resetState();
  $("#auth").hidden = true; $("#app").hidden = false;
  $("#userName").textContent = S.user.name || S.user.shown;
  $("#scopeSeg").hidden = !S.user.is_admin;
  S.account = S.user.account || null;
  renderAccount();

  const b = await api("/api/bootstrap");
  S.cfg = b; S.cities = b.cities; S.stations = b.stations;
  S.byId = Object.fromEntries(b.stations.map((s) => [s.id, s]));
  if (!S.cities.find((c) => c.name === S.city)) S.city = S.cities[0].name;
  if (!b.ev_models.find((m) => m.name === S.form.model)) S.form.model = "Tata Nexon EV";
  if (S.form.model !== "Custom battery") S.form.capacity = b.ev_models.find((m) => m.name === S.form.model).kwh;
  if (!S.form.name) S.form.name = S.user.name || "";

  const r = b.rates;
  $("#ratesNote").innerHTML = `₹${r.electricity}/kWh + ₹${r.charging}/min charging<br>₹${r.idle}/min idle + ₹${r.fixed} fixed fee`;
  $("#city").innerHTML = S.cities.map((c) => `<option value="${esc(c.name)}">${esc(c.name)}, ${esc(c.state)}</option>`).join("");
  $("#city").value = S.city;

  if (!S.bound) { bindUI(); S.bound = true; }
  showTab("stations");
  renderStations(true);
  initMap();
  poll(S.polling);
  refreshIssues(true);
  refreshHistory();
}

async function poll(gen) {
  if (gen !== S.polling || !S.user) return;
  try {
    const d = await api("/api/state?after=" + (S.lastEvent ?? 999999999));
    if (gen !== S.polling) return;
    setOnline(true);
    applyState(d);
  } catch (e) {
    if (S.user) setOnline(false);
  } finally {
    setTimeout(() => poll(gen), 1000);
  }
}
function setOnline(ok) {
  if (ok === S.online) return;
  S.online = ok;
  toast(ok ? "Connection restored." : "Lost connection to the server. Is app.py still running?", ok ? "ok" : "bad");
}

function applyState(d) {
  S.slots = d.slots;
  S.sessions = d.sessions;
  if (d.account) { S.account = d.account; renderAccount(); }
  $("#clock").textContent = d.sim_hms;
  if ($("#speed").value !== String(d.speed)) $("#speed").value = String(d.speed);

  if (S.lastEvent === null) S.lastEvent = d.last_event; // don't replay old messages on page load
  else {
    d.events.forEach((e) => toast(e.message, e.kind));
    S.lastEvent = d.last_event;
  }
  renderStations(false);
  if (S.drawerId) refreshDrawerSlots();
  renderSessions(false);
  setCount("[data-bookings-count]", S.sessions.length);
}

// no-show fines: strike pill in the header + a notice above the pages
function renderAccount() {
  const a = S.account;
  if (!a) return;
  const sig = [a.strikes, a.blocked, a.fine_pending].join("|");
  if (sig === S.sigAcct) return;
  const blockedBefore = S.sigAcct.split("|")[1] === "true";
  S.sigAcct = sig;

  const pill = $("#strikePill");
  pill.hidden = a.strikes === 0;
  pill.className = "strike-pill" + (a.blocked ? " blocked" : a.strikes >= a.max_strikes - 1 ? " last" : "");
  pill.textContent = a.blocked ? "Account blocked" : `No-shows ${a.strikes}/${a.max_strikes}`;
  pill.title = `₹${a.fine_amount} fine for every booking you don't start in time. ${a.max_strikes} no-shows blocks the account.`;

  const box = $("#acctBanner");
  if (a.blocked) {
    box.className = "acct-banner blocked";
    box.innerHTML = `<b>Your account is blocked from new bookings.</b> You missed ${a.max_strikes} booked slots without starting to charge (₹${a.fine_amount} fine each).
      You can still finish and pay for any charging already in progress. Please contact the station staff to get your account reopened.`;
    box.hidden = false;
  } else if (a.strikes > 0) {
    const left = a.max_strikes - a.strikes;
    box.className = "acct-banner" + (left <= 1 ? " last" : "");
    box.innerHTML = `<b>No-show warning: ${a.strikes} of ${a.max_strikes}.</b> A booking you don't start within ${S.cfg.rates.hold_minutes} minutes costs ₹${a.fine_amount}.
      ${left === 1 ? "<b>One more and your account will be blocked.</b>" : `${left} more and your account will be blocked.`}
      ${a.fine_pending > 0 ? `Fines to pay with your next bill: <b>${inr(a.fine_pending)}</b>.` : ""}`;
    box.hidden = false;
  } else {
    box.hidden = true;
  }
  // the booking form in an open drawer depends on the blocked state
  if (S.drawerId && blockedBefore !== a.blocked) renderBookForm();
}

function setCount(sel, n) {
  $$(sel).forEach((el) => { el.textContent = n; el.classList.toggle("show", n > 0); });
}

// ------------------------------------------------------------ tabs and general UI
function showTab(tab) {
  S.tab = tab;
  $$(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  $$(".view").forEach((v) => v.classList.toggle("active", v.id === "view-" + tab));
  window.scrollTo(0, 0);
  if (tab === "payments") refreshHistory();
  if (tab === "issues") refreshIssues();
  if (tab === "bookings") renderSessions(true);
  if (tab === "stations" && GM.map) setTimeout(() => google.maps.event.trigger(GM.map, "resize"), 50);
}

function bindUI() {
  $$(".tab").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));
  $("#logoutBtn").onclick = logout;
  $("#city").onchange = (e) => setCity(e.target.value);
  $("#q").oninput = (e) => { S.query = e.target.value.trim().toLowerCase(); renderStations(true); };
  $("#filter").onchange = (e) => { S.filter = e.target.value; renderStations(true); };
  $("#sort").onchange = (e) => {
    S.sort = e.target.value;
    if (S.sort === "near" && !S.userPos) locate(); else renderStations(true);
  };
  $("#nearBtn").onclick = locate;
  $("#speed").onchange = async (e) => {
    try { await api("/api/speed", { body: { speed: Number(e.target.value) } }); toast("Timer speed changed."); }
    catch (er) { toast(er.message, "bad"); }
  };
  $("#scrim").onclick = closeDrawer;
  $("#payModal").addEventListener("click", (e) => { if (e.target.id === "payModal") closePay(); });
  $("#issueModal").addEventListener("click", (e) => { if (e.target.id === "issueModal") closeIssueModal(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeDrawer(); closePay(); closeIssueModal(); } });

  $("#newIssueBtn").onclick = () => openIssueForm();
  $("#issueStatus").onchange = renderIssues;
  $$("#scopeSeg button").forEach((b) => (b.onclick = () => {
    S.issueScope = b.dataset.scope;
    $$("#scopeSeg button").forEach((x) => x.classList.toggle("on", x === b));
    refreshIssues();
  }));

  // one click handler for everything rendered from templates
  document.addEventListener("click", (ev) => {
    const el = ev.target.closest("[data-act]");
    if (!el) return;
    const a = el.dataset.act;
    if (a === "open") openDrawer(el.dataset.id);
    else if (a === "fav") { ev.stopPropagation(); toggleFav(el.dataset.id); }
    else if (a === "close-drawer") closeDrawer();
    else if (a === "slot") { S.slotIdx = Number(el.dataset.idx); renderDrawerSlots(); renderBookForm(); }
    else if (a === "copy") navigator.clipboard?.writeText(el.dataset.text).then(() => toast("Address copied.", "ok"));
    else if (a === "book") submitBooking();
    else if (a === "sess") sessionAction(el.dataset.sid, el.dataset.do);
    else if (a === "pay") openPay(el.dataset.sid);
    else if (a === "go-stations") showTab("stations");
    else if (a === "report") openIssueForm({ station_id: el.dataset.station, slot: el.dataset.slot || "" });
    else if (a === "issue") openIssue(el.dataset.id);
  });
}

function locate() {
  if (!navigator.geolocation) return toast("Location is not available in this browser.", "warn");
  toast("Finding your location...");
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      S.userPos = [pos.coords.latitude, pos.coords.longitude];
      let best = null;
      S.cities.forEach((c) => { const d = haversine(S.userPos, c.center); if (!best || d < best.d) best = { c, d }; });
      if (best && best.d < 80) { S.city = best.c.name; store.set("ev_city", S.city); $("#city").value = S.city; }
      else toast("No supported city within 80 km of you. Distances are still shown.", "warn");
      S.sort = "near"; $("#sort").value = "near";
      mapShowMe();
      renderStations(true);
    },
    () => { toast("Couldn't get your location. You can still choose a city.", "warn"); S.sort = "best"; $("#sort").value = "best"; renderStations(true); },
    { enableHighAccuracy: false, timeout: 8000 }
  );
}

// ------------------------------------------------------------ stations
function setCity(name) {
  S.city = name; store.set("ev_city", name);
  GM.fitKey = "";
  renderStations(true);
}

function toggleFav(id) {
  S.favs.has(id) ? S.favs.delete(id) : S.favs.add(id);
  store.set("ev_favs", [...S.favs]);
  renderStations(true);
  if (S.drawerId === id) renderDrawer();
}

const freeCount = (st) => (S.slots[st.id] || []).filter((x) => x.st === "FREE").length;

function stationScore(st) {
  let score = freeCount(st) * 2 + st.rating * 2 + (st.max_power >= FAST_KW ? 2 : 0);
  if (freeCount(st) === 0) score -= 20;
  if (S.userPos) score -= haversine(S.userPos, [st.lat, st.lng]) * 0.3;
  return score;
}

function visibleStations() {
  let list = S.stations.filter((s) => s.city === S.city);
  if (S.query) list = list.filter((s) => (s.name + " " + s.address + " " + s.amenities.join(" ")).toLowerCase().includes(S.query));
  if (S.filter === "fast") list = list.filter((s) => s.max_power >= FAST_KW);
  if (S.filter === "free") list = list.filter((s) => freeCount(s) > 0);
  if (S.filter === "saved") list = list.filter((s) => S.favs.has(s.id));
  const dist = (s) => (S.userPos ? haversine(S.userPos, [s.lat, s.lng]) : 1e9);
  const sorters = {
    best: (a, b) => stationScore(b) - stationScore(a),
    near: (a, b) => dist(a) - dist(b),
    rating: (a, b) => b.rating - a.rating,
    free: (a, b) => freeCount(b) - freeCount(a),
  };
  return list.sort(sorters[S.sort] || sorters.best);
}

function renderStations(force) {
  const list = visibleStations();
  const inCity = S.stations.filter((s) => s.city === S.city);
  let free = 0, total = 0;
  inCity.forEach((s) => (S.slots[s.id] || []).forEach((x) => { total++; if (x.st === "FREE") free++; }));
  $("#cityNote").textContent = total ? `${inCity.length} stations in ${S.city}. ${free} of ${total} slots are free right now.` : `${inCity.length} stations in ${S.city}.`;

  const sig = [S.city, S.filter, S.sort, S.query, [...S.favs].join(), S.userPos ? 1 : 0, S.drawerId,
    list.map((s) => s.id + ":" + (S.slots[s.id] || []).map((x) => x.st[0]).join("")).join("|")].join("#");
  if (!force && sig === S.sigList) return;
  S.sigList = sig;

  if (!list.length) {
    $("#stationList").innerHTML = `<div class="empty"><h3>No stations found</h3><p>Nothing in ${esc(S.city)} matches these filters.</p></div>`;
    mapUpdate(list);
    return;
  }
  $("#stationList").innerHTML = list.map((st) => {
    const sl = S.slots[st.id] || [];
    const free = sl.filter((x) => x.st === "FREE").length;
    const km = S.userPos ? haversine(S.userPos, [st.lat, st.lng]) : null;
    return `
    <div class="station ${st.id === S.drawerId ? "current" : ""}" data-act="open" data-id="${st.id}">
      <div>
        <h3>${esc(st.name)}</h3>
        <div class="addr">${esc(st.address)}</div>
        <div class="meta">Up to <b>${st.max_power} kW</b> &middot; Rating <b>${st.rating.toFixed(1)}</b>${km !== null ? ` &middot; <b>${km < 10 ? km.toFixed(1) : Math.round(km)} km</b> away` : ""}</div>
        <div class="meta">${st.amenities.map((a) => `<span class="tag">${esc(a)}</span>`).join("")}</div>
      </div>
      <div class="right">
        <button class="star ${S.favs.has(st.id) ? "on" : ""}" data-act="fav" data-id="${st.id}" aria-label="${S.favs.has(st.id) ? "Remove from saved" : "Save station"}" title="${S.favs.has(st.id) ? "Saved" : "Save station"}">${S.favs.has(st.id) ? "★" : "☆"}</button>
        <div class="slotline">${sl.map((x) => `<i class="sq ${x.st}" title="${x.st.toLowerCase()}"></i>`).join("")}</div>
        <div class="avail ${free ? "" : "none"}">${free ? `${free} of ${sl.length} free` : "No free slot"}</div>
      </div>
    </div>`;
  }).join("");
  mapUpdate(list);
}

// ------------------------------------------------------------ Google Map
const GM = { map: null, markers: new Map(), me: null, lib: null, failed: false, fitKey: "", loading: null };

function mapMessage(html) {
  const el = $("#mapMsg");
  el.innerHTML = html; el.hidden = !html;
}

function loadMapsScript(key) {
  if (window.google && google.maps && google.maps.importLibrary) return Promise.resolve();
  if (GM.loading) return GM.loading;
  GM.loading = new Promise((resolve, reject) => {
    window.__mapsReady = resolve;
    window.gm_authFailure = () => {
      GM.failed = true;
      mapMessage("<div><b>Google Maps rejected the API key.</b><br>Check that the key in <code>.env</code> is correct, that the <i>Maps JavaScript API</i> is enabled and that billing is active for the project.</div>");
    };
    const s = document.createElement("script");
    s.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}&v=weekly&loading=async&callback=__mapsReady`;
    s.async = true;
    s.onerror = () => reject(new Error("Could not reach Google Maps. Check your internet connection."));
    document.head.appendChild(s);
  });
  return GM.loading;
}

async function initMap() {
  if (GM.map) { mapUpdate(visibleStations()); return; }
  const key = S.cfg.maps.key;
  if (!key) {
    mapMessage("<div><b>Google Maps is not set up yet.</b><br>Add your key to the <code>.env</code> file as <code>GOOGLE_MAPS_API_KEY</code> and restart the app. The station list works without it.</div>");
    return;
  }
  try {
    await loadMapsScript(key);
    const { Map } = await google.maps.importLibrary("maps");
    GM.lib = await google.maps.importLibrary("marker");
    const c = S.cities.find((x) => x.name === S.city);
    GM.map = new Map($("#map"), {
      center: { lat: c.center[0], lng: c.center[1] }, zoom: 12, mapId: S.cfg.maps.map_id,
      streetViewControl: false, mapTypeControl: false, fullscreenControl: false,
    });
    mapMessage("");
    mapUpdate(visibleStations());
    mapShowMe();
  } catch (e) {
    mapMessage(`<div><b>The map could not load.</b><br>${esc(e.message)}</div>`);
  }
}

function pinElement(free, picked) {
  const d = document.createElement("div");
  d.className = "pin " + (free === 0 ? "none" : free <= 1 ? "low" : "") + (picked ? " picked" : "");
  d.textContent = free;
  return d;
}

function mapUpdate(list) {
  if (!GM.map || !GM.lib) return;
  const keep = new Set(list.map((s) => s.id));
  GM.markers.forEach((m, id) => { if (!keep.has(id)) { m.map = null; GM.markers.delete(id); } });
  list.forEach((st) => {
    const content = pinElement(freeCount(st), st.id === S.drawerId);
    let m = GM.markers.get(st.id);
    if (m) m.content = content;
    else {
      m = new GM.lib.AdvancedMarkerElement({ map: GM.map, position: { lat: st.lat, lng: st.lng }, content, title: st.name });
      m.addListener("click", () => openDrawer(st.id));
      GM.markers.set(st.id, m);
    }
  });
  const key = S.city + "|" + S.filter + "|" + S.query;
  if (list.length && GM.fitKey !== key) {
    GM.fitKey = key;
    const b = new google.maps.LatLngBounds();
    list.forEach((s) => b.extend({ lat: s.lat, lng: s.lng }));
    if (S.userPos) b.extend({ lat: S.userPos[0], lng: S.userPos[1] });
    GM.map.fitBounds(b, 50);
    google.maps.event.addListenerOnce(GM.map, "idle", () => { if (GM.map.getZoom() > 15) GM.map.setZoom(15); });
  }
}

function mapShowMe() {
  if (!GM.map || !GM.lib || !S.userPos) return;
  const el = document.createElement("div"); el.className = "me-dot";
  if (GM.me) GM.me.map = null;
  GM.me = new GM.lib.AdvancedMarkerElement({ map: GM.map, position: { lat: S.userPos[0], lng: S.userPos[1] }, content: el, title: "You are here" });
}

// ------------------------------------------------------------ station drawer + booking
function openDrawer(id) {
  const st = S.byId[id];
  if (!st) return;
  S.drawerId = id;
  const sl = S.slots[id] || [];
  const firstFree = sl.findIndex((x) => x.st === "FREE");
  S.slotIdx = firstFree >= 0 ? firstFree : null;
  S.sigDrawer = sl.map((x) => x.st).join();
  renderDrawer();
  $("#drawer").classList.add("open");
  $("#scrim").classList.add("show");
  renderStations(true);
  if (GM.map) { GM.map.panTo({ lat: st.lat, lng: st.lng }); GM.map.setZoom(15); }
}
function closeDrawer() {
  if (!S.drawerId) return;
  S.drawerId = null;
  $("#drawer").classList.remove("open");
  $("#scrim").classList.remove("show");
  renderStations(true);
}

function renderDrawer() {
  const st = S.byId[S.drawerId];
  if (!st) return;
  let dir = `https://www.google.com/maps/dir/?api=1&destination=${st.lat},${st.lng}`;
  if (S.userPos) dir += `&origin=${S.userPos[0]},${S.userPos[1]}`;
  const km = S.userPos ? haversine(S.userPos, [st.lat, st.lng]) : null;
  $("#drawer").innerHTML = `
    <button class="x" data-act="close-drawer" aria-label="Close">&times;</button>
    <h2>${esc(st.name)}</h2>
    <div class="addr">${esc(st.address)}</div>
    <div class="addr">Open 24 hours &middot; Rating ${st.rating.toFixed(1)}${km !== null ? ` &middot; ${km.toFixed(1)} km away` : ""}</div>
    <div class="tags">${st.amenities.map((a) => `<span class="tag">${esc(a)}</span>`).join("")}</div>
    <div class="links">
      <a class="btn small" href="${dir}" target="_blank" rel="noopener">Directions in Google Maps</a>
      <button class="btn small" data-act="copy" data-text="${esc(st.name + ", " + st.address)}">Copy address</button>
      <button class="btn small" data-act="fav" data-id="${st.id}">${S.favs.has(st.id) ? "Saved ★" : "Save ☆"}</button>
      <button class="btn small" data-act="report" data-station="${st.id}">Report an issue</button>
    </div>
    <div class="h-sec">Choose a slot</div>
    <div class="slot-grid" id="dSlots"></div>
    <div class="h-sec">Your vehicle and charge</div>
    <div id="dForm"></div>`;
  renderDrawerSlots();
  renderBookForm();
}

function refreshDrawerSlots() {
  const sl = S.slots[S.drawerId] || [];
  const sig = sl.map((x) => x.st).join();
  if (sig === S.sigDrawer) return;
  S.sigDrawer = sig;
  if (S.slotIdx !== null && sl[S.slotIdx] && sl[S.slotIdx].st !== "FREE") {
    const f = sl.findIndex((x) => x.st === "FREE");
    S.slotIdx = f >= 0 ? f : null;
    renderDrawerSlots(); renderBookForm();
  } else {
    if (S.slotIdx === null) { const f = sl.findIndex((x) => x.st === "FREE"); if (f >= 0) { S.slotIdx = f; renderBookForm(); } }
    renderDrawerSlots();
  }
}

const STATUS_LABEL = { FREE: "Free", BOOKED: "Booked", CHARGING: "Charging", IDLE: "In use (idle)", PAYMENT: "Paying" };
function renderDrawerSlots() {
  const st = S.byId[S.drawerId], el = $("#dSlots");
  if (!st || !el) return;
  const sl = S.slots[st.id] || [];
  el.innerHTML = st.slots.map((s, i) => {
    const status = (sl[i] || { st: "FREE" }).st;
    const free = status === "FREE";
    return `<button class="slot-btn ${free ? "free" : "busy"} ${S.slotIdx === i ? "sel" : ""}" ${free ? `data-act="slot" data-idx="${i}"` : "disabled"}>
      <b>${s.power} kW</b><small>${esc(s.label)} &middot; ${esc(s.connector)}</small>
      <span class="st">${STATUS_LABEL[status] || status}</span>
    </button>`;
  }).join("");
}

function renderBookForm() {
  const st = S.byId[S.drawerId], el = $("#dForm");
  if (!st || !el) return;
  if (S.slotIdx === null) {
    el.innerHTML = `<div class="empty"><h3>All slots are taken</h3><p>Try another station. A slot shows as free here as soon as someone unplugs.</p></div>`;
    return;
  }
  if (S.account && S.account.blocked) {
    el.innerHTML = `<div class="empty blocked-box"><h3>Booking is switched off</h3><p>Your account is blocked after ${S.account.max_strikes} no-shows. Please contact the station staff.</p></div>`;
    return;
  }
  const f = S.form;
  el.innerHTML = `
    <div class="two">
      <div class="field"><label for="f-name">Your name</label><input class="input" id="f-name" value="${esc(f.name)}" maxlength="40"></div>
      <div class="field"><label for="f-veh">Vehicle number</label><input class="input" id="f-veh" value="${esc(f.vehicle)}" placeholder="TS09AB1234" maxlength="14" style="text-transform:uppercase"></div>
    </div>
    <div class="field"><label for="f-model">Vehicle model</label>
      <select class="sel" id="f-model" style="width:100%">${S.cfg.ev_models.map((m) => `<option ${m.name === f.model ? "selected" : ""} value="${esc(m.name)}">${esc(m.name)} (${m.kwh} kWh)</option>`).join("")}</select>
    </div>
    <div class="field" id="f-cap-wrap" style="display:${f.model === "Custom battery" ? "block" : "none"}"><label for="f-cap">Battery size (kWh)</label><input class="input" id="f-cap" type="number" min="1" max="150" step="0.1" value="${f.capacity}"></div>
    <div class="field"><div class="range-head"><label for="f-start">Battery level now</label><b id="f-start-v">${f.start}%</b></div><input type="range" id="f-start" min="0" max="95" value="${f.start}"></div>
    <div class="field"><div class="range-head"><label for="f-target">Charge up to</label><b id="f-target-v">${f.target}%</b></div><input type="range" id="f-target" min="5" max="100" value="${f.target}"></div>
    <div class="est" id="est"></div>
    <button class="btn primary block" data-act="book">Book this slot</button>
    <p class="note fine-note" style="margin-top:8px">The slot is held for ${S.cfg.rates.hold_minutes} minutes. If you have not started charging by then, the booking is cancelled and a <b>₹${S.cfg.rates.fine} no-show fine</b> is added to your next bill${S.account ? ` (no-shows so far: ${S.account.strikes} of ${S.cfg.rates.max_strikes}; at ${S.cfg.rates.max_strikes} your account is blocked)` : ""}. Cancel before the time runs out to avoid it.</p>`;
  bindForm();
  updateEstimate();
}

function bindForm() {
  const f = S.form;
  const save = () => store.set("ev_form", { name: f.name, vehicle: f.vehicle, model: f.model, capacity: f.capacity });
  $("#f-name").oninput = (e) => { f.name = e.target.value; save(); };
  $("#f-veh").oninput = (e) => { f.vehicle = e.target.value.toUpperCase(); e.target.value = f.vehicle; save(); };
  $("#f-model").onchange = (e) => {
    f.model = e.target.value;
    const m = S.cfg.ev_models.find((x) => x.name === f.model);
    f.capacity = m ? m.kwh : f.capacity;
    $("#f-cap-wrap").style.display = f.model === "Custom battery" ? "block" : "none";
    $("#f-cap").value = f.capacity;
    save(); updateEstimate();
  };
  $("#f-cap").oninput = (e) => { f.capacity = Number(e.target.value) || 0; save(); updateEstimate(); };
  $("#f-start").oninput = (e) => {
    f.start = Number(e.target.value);
    if (f.target <= f.start) { f.target = Math.min(100, f.start + 1); $("#f-target").value = f.target; }
    updateEstimate();
  };
  $("#f-target").oninput = (e) => {
    f.target = Number(e.target.value);
    if (f.target <= f.start) { f.start = Math.max(0, f.target - 1); $("#f-start").value = f.start; }
    updateEstimate();
  };
}

function updateEstimate() {
  const st = S.byId[S.drawerId], el = $("#est");
  if (!st || !el || S.slotIdx === null) return;
  const f = S.form, slot = st.slots[S.slotIdx], r = S.cfg.rates;
  $("#f-start-v").textContent = f.start + "%";
  $("#f-target-v").textContent = f.target + "%";
  const kwh = Math.max(0, f.capacity * (f.target - f.start) / 100);
  const mins = Math.ceil(Math.round((kwh / slot.power) * 60 * 1e6) / 1e6);
  const cost = kwh * r.electricity + mins * r.charging + r.fixed;
  el.innerHTML = `<div><b>${kwh.toFixed(1)}</b><span>kWh needed</span></div><div><b>about ${mins} min</b><span>charging time</span></div><div><b>${inr(cost).replace(".00", "")}</b><span>estimated cost</span></div>`;
}

async function submitBooking() {
  const f = S.form, st = S.byId[S.drawerId];
  if (!st || S.slotIdx === null) return;
  try {
    await api("/api/book", { body: { station_id: st.id, slot_idx: S.slotIdx, name: f.name, vehicle: f.vehicle, ev_model: f.model, capacity: f.capacity, start_soc: f.start, target_soc: f.target } });
    toast(`Slot booked at ${st.name}.`, "ok");
    closeDrawer();
    applyState(await api("/api/state?after=" + S.lastEvent));
    showTab("bookings");
  } catch (e) { toast(e.message, "bad"); }
}

// ------------------------------------------------------------ my bookings
function sessionCard(s) {
  const actions = {
    BOOKED: `<button class="btn primary" data-act="sess" data-do="start" data-sid="${s.id}">Start charging</button>
             <button class="btn danger" data-act="sess" data-do="cancel" data-sid="${s.id}">Cancel booking</button>`,
    CHARGING: `<button class="btn" data-act="sess" data-do="stop" data-sid="${s.id}">Pause</button>
               <button class="btn primary" data-act="sess" data-do="unplug" data-sid="${s.id}">Unplug and get bill</button>`,
    IDLE: `<button class="btn primary" data-act="sess" data-do="unplug" data-sid="${s.id}">Unplug and get bill</button>`,
    PAYMENT: `<button class="btn primary" data-act="pay" data-sid="${s.id}">Pay now</button>`,
  }[s.state] || "";
  const banner = {
    BOOKED: `<div class="banner info">Slot held for <b data-f="hold">--:--</b>. Start charging before the time runs out or a <b>₹${S.cfg.rates.fine} no-show fine</b> applies (cancelling early is free).<div class="holdbar"><i data-f="holdbar"></i></div></div>`,
    CHARGING: `<div class="banner">Charging at ${s.power} kW. Target is ${s.target_soc}%.</div>`,
    IDLE: `<div class="banner warn">Charging is finished. Idle fee of ₹${S.cfg.rates.idle} per minute is running, please unplug.</div>`,
    PAYMENT: `<div class="banner pay">Your bill is ready: ${inr(s.bill.total)}${s.bill.fine_cost ? ` (includes ${inr(s.bill.fine_cost)} no-show fines)` : ""}</div>`,
  }[s.state] || "";
  return `
  <article class="sess st-${s.state}" data-sid="${s.id}">
    <div class="sess-head">
      <div><h3>${esc(s.station_name)}</h3><div class="addr">${esc(s.station_address)}</div></div>
      <span class="state-pill ${s.state}">${esc(s.state_text)}</span>
    </div>
    <div class="sess-info"><b>${esc(s.slot_label)}</b> (${esc(s.connector)}, ${s.power} kW) &middot; <b>${esc(s.vehicle)}</b> &middot; ${esc(s.ev_model)}</div>
    <div class="bar"><i data-f="bar" style="width:${s.soc}%"></i></div>
    <div class="bar-label"><span>Battery <b data-f="soc">0%</b></span><span>Started at ${s.start_soc}%, target ${s.target_soc}%</span></div>
    ${banner}
    <div class="tiles">
      <div class="tile"><span>Energy</span><b data-f="energy">0.00 kWh</b></div>
      <div class="tile"><span>Charging time</span><b data-f="ctime">00:00:00</b></div>
      <div class="tile"><span>Idle time</span><b data-f="itime">00:00:00</b></div>
      <div class="tile"><span>Bill so far</span><b data-f="cost">-</b></div>
    </div>
    <div class="actions">${actions}<button class="linkish" data-act="report" data-station="${s.station_id}" data-slot="${esc(s.slot_label)}">Report a problem</button></div>
  </article>`;
}

function renderSessions(force) {
  const sig = S.sessions.map((s) => s.id + s.state + (s.promo || "")).join("|");
  if (force || sig !== S.sigSessions) {
    S.sigSessions = sig;
    $("#sessions").innerHTML = S.sessions.length
      ? S.sessions.map(sessionCard).join("")
      : `<div class="empty" style="grid-column:1/-1"><h3>No active bookings</h3><p>Choose a station and book a slot. It will show up here with live charging details.</p><button class="btn primary" data-act="go-stations">Find a station</button></div>`;
  }
  S.sessions.forEach(updateSessionLive);
}

function updateSessionLive(s) {
  const card = $(`.sess[data-sid="${s.id}"]`);
  if (!card) return;
  const set = (f, v) => { const el = $(`[data-f="${f}"]`, card); if (el && el.textContent !== v) el.textContent = v; };
  set("soc", Math.round(s.soc) + "%");
  const bar = $('[data-f="bar"]', card);
  if (bar) bar.style.width = Math.min(100, s.soc) + "%";
  set("energy", s.bill.energy_kwh.toFixed(2) + " kWh");
  set("ctime", hms(s.charge_seconds));
  set("itime", hms(s.idle_seconds));
  set("cost", s.state === "BOOKED" ? "-" : inr(s.bill.total));
  if (s.state === "BOOKED") {
    set("hold", mmss(s.hold_left));
    const hb = $('[data-f="holdbar"]', card);
    if (hb) hb.style.width = (100 * s.hold_left / s.hold_total).toFixed(1) + "%";
  }
}

async function sessionAction(sid, action) {
  try {
    if (action === "cancel" && !confirm("Cancel this booking? You will not be charged and it will not count as a no-show.")) return;
    await api(`/api/session/${sid}/${action}`, { method: "POST", body: {} });
    if (action === "cancel") toast("Booking cancelled.");
    if (action === "start") toast("Charging started.", "ok");
    if (action === "stop") toast("Charging paused. The idle fee applies until you unplug.", "warn");
    applyState(await api("/api/state?after=" + S.lastEvent));
    renderSessions(true);
    if (action === "unplug") openPay(sid);
  } catch (e) { toast(e.message, "bad"); }
}

// ------------------------------------------------------------ payments
const PM = { sid: null, stage: "bill", qr: null, tick: null, total: 0, invoice: null, method: "" };
const PP = {}; // qr id -> poll timer (keeps checking even if the dialog is closed)

function openPay(sid) {
  PM.sid = sid; PM.stage = "bill"; PM.qr = null; PM.invoice = null;
  $("#payModal").classList.add("show");
  renderPay();
}
function closePay() {
  $("#payModal").classList.remove("show");
  clearInterval(PM.tick); PM.tick = null;
}
const sessionById = (id) => S.sessions.find((s) => s.id === id);

function renderPay() {
  const card = $("#payCard");
  if (PM.stage === "success") return renderPaySuccess();
  const s = sessionById(PM.sid);
  if (!s || s.state !== "PAYMENT") { if (PM.stage === "bill") closePay(); return; }
  if (PM.stage === "qr" && PM.qr) return renderPayQr();
  const b = s.bill, r = S.cfg.rates;
  card.innerHTML = `
    <button class="x" id="payX" aria-label="Close">&times;</button>
    <h2>Your bill</h2>
    <p class="note">${esc(s.station_name)} &middot; ${esc(s.slot_label)} &middot; ${esc(s.vehicle)}</p>
    <div style="margin-top:10px">
      <div class="bill-row"><span>Electricity: ${b.energy_kwh.toFixed(2)} kWh × ₹${r.electricity}</span><b>${inr(b.electricity_cost)}</b></div>
      <div class="bill-row"><span>Charging time: ${b.charge_minutes} min × ₹${r.charging}</span><b>${inr(b.charging_cost)}</b></div>
      <div class="bill-row"><span>Idle time: ${b.idle_minutes} min × ₹${r.idle}</span><b>${inr(b.idle_cost)}</b></div>
      <div class="bill-row"><span>Fixed station fee</span><b>${inr(b.fixed_cost)}</b></div>
      ${b.discount ? `<div class="bill-row disc"><span>Promo code ${esc(b.promo)}</span><b>−${inr(b.discount)}</b></div>` : ""}
      ${b.fine_cost ? `<div class="bill-row fine"><span>No-show fines (${Math.round(b.fine_cost / S.cfg.rates.fine)} × ₹${S.cfg.rates.fine})</span><b>${inr(b.fine_cost)}</b></div>` : ""}
    </div>
    <div class="bill-total"><span>Total</span><b>${inr(b.total)}</b></div>
    <div class="promo-row">
      <input class="input" id="promo" placeholder="Promo code" value="${esc(s.promo || "")}" style="text-transform:uppercase">
      <button class="btn" id="promoBtn">Apply</button>
    </div>
    <div class="promo-chips">Try: ${Object.entries(S.cfg.promos).map(([c, d]) => `<button title="${esc(d)}" data-code="${esc(c)}">${esc(c)}</button>`).join("")}</div>
    <div class="stack">
      <button class="btn primary block" id="payQr">Pay ${inr(b.total)} with UPI QR</button>
      <button class="btn block" id="payCash">Pay cash at the counter</button>
      <button class="btn block" id="payLater" style="border-color:transparent">Pay later</button>
    </div>`;
  $("#payX").onclick = closePay;
  $("#promoBtn").onclick = () => applyPromo($("#promo").value);
  $$(".promo-chips button", card).forEach((b2) => (b2.onclick = () => { $("#promo").value = b2.dataset.code; applyPromo(b2.dataset.code); }));
  $("#payQr").onclick = startQr;
  $("#payCash").onclick = payCash;
  $("#payLater").onclick = closePay;
}

async function applyPromo(code) {
  try {
    const r = await api(`/api/session/${PM.sid}/promo`, { body: { code } });
    const i = S.sessions.findIndex((x) => x.id === PM.sid);
    if (i >= 0) S.sessions[i] = r.session;
    toast(code.trim() ? "Promo code applied." : "Promo code removed.", "ok");
    renderPay(); renderSessions(true);
  } catch (e) { toast(e.message, "bad"); }
}

async function payCash() {
  if (!confirm("Pay the full amount in cash at the station counter?")) return;
  try {
    const r = await api(`/api/session/${PM.sid}/pay/cash`, { method: "POST", body: {} });
    PM.stage = "success"; PM.invoice = r.invoice; PM.total = r.total; PM.method = "Cash";
    afterPaid();
  } catch (e) { toast(e.message, "bad"); }
}

async function startQr() {
  const btn = $("#payQr");
  btn.disabled = true; btn.textContent = "Generating QR code...";
  try {
    const q = await api(`/api/session/${PM.sid}/pay/qr`, { method: "POST", body: {} });
    PM.qr = q; PM.stage = "qr"; PM.total = q.amount; PM.method = "UPI";
    PM.expiresAt = Date.now() + q.seconds_left * 1000;
    renderPay();
    watchPayment(q.qr_id);
  } catch (e) {
    toast(e.message, "bad");
    btn.disabled = false; btn.textContent = "Try again";
  }
}

function renderPayQr() {
  const q = PM.qr, demo = q.mode === "demo";
  $("#payCard").innerHTML = `
    <button class="x" id="payX" aria-label="Close">&times;</button>
    <div class="qr-stage">
      <h2>Scan and pay</h2>
      <p class="note">${demo ? "Demo mode: add Razorpay keys in .env to take real payments." : "Razorpay UPI QR. Works with any UPI app."}</p>
      <div class="qr-box">
        ${q.image ? `<img src="${esc(q.image)}" alt="UPI payment QR code">` : `<div style="padding:10px;font-size:13px;word-break:break-all">${esc(q.upi || "QR image unavailable")}</div>`}
      </div>
      <div class="qr-amount">${inr(q.amount)}</div>
      <div class="apps">GPay, PhonePe, Paytm, BHIM or any UPI app</div>
      <div class="status-line" id="qrStatus">Waiting for payment. Expires in <b id="qrLeft">--:--</b></div>
      ${demo ? `<button class="btn primary block" id="simPay" style="margin-top:14px">Simulate payment (demo only)</button>` : `<p class="note" style="margin-top:12px">With test keys, UPI apps can't pay this QR. Simulate the payment from the Razorpay dashboard (Test mode, QR Codes).</p>`}
      <button class="btn block" id="qrBack" style="margin-top:8px;border-color:transparent">Back to bill</button>
    </div>`;
  $("#payX").onclick = closePay;
  const left = () => { const el = $("#qrLeft"); if (el) el.textContent = mmss((PM.expiresAt - Date.now()) / 1000); };
  left(); clearInterval(PM.tick); PM.tick = setInterval(left, 1000);
  if ($("#simPay")) $("#simPay").onclick = async () => {
    try { await api(`/api/payments/${q.qr_id}/simulate`, { method: "POST", body: {} }); } catch (e) { toast(e.message, "bad"); }
  };
  $("#qrBack").onclick = () => { PM.stage = "bill"; clearInterval(PM.tick); renderPay(); };
}

function watchPayment(qrId) {
  if (PP[qrId]) return;
  const check = async () => {
    try {
      const r = await api(`/api/payments/${qrId}`);
      const shown = $("#payModal").classList.contains("show") && PM.qr && PM.qr.qr_id === qrId;
      if (r.status === "paid") {
        stopWatch(qrId);
        PM.total = r.amount; PM.invoice = r.invoice; PM.method = r.mode === "demo" ? "UPI (demo QR)" : "UPI (Razorpay QR)";
        if (shown) PM.stage = "success";
        afterPaid(!shown);
      } else if (r.status === "expired" || r.status === "cancelled") {
        stopWatch(qrId);
        if (shown && PM.stage === "qr") {
          const st = $("#qrStatus");
          if (st) st.textContent = r.status === "expired" ? "This QR code has expired." : "This QR code was replaced.";
          clearInterval(PM.tick);
          $("#qrBack").textContent = "Generate a new QR code";
          $("#qrBack").onclick = () => { PM.stage = "bill"; renderPay(); };
        }
      } else if (r.warning) console.warn(r.warning);
    } catch (e) { /* network hiccup, try again on the next tick */ }
  };
  PP[qrId] = setInterval(check, 2500);
  check();
}
function stopWatch(id) { clearInterval(PP[id]); delete PP[id]; }

function afterPaid(background) {
  clearInterval(PM.tick);
  refreshHistory();
  api("/api/state?after=" + S.lastEvent).then((d) => { applyState(d); renderSessions(true); }).catch(() => {});
  if (background) { toast(`Payment of ${inr(PM.total)} received. Invoice ${PM.invoice || ""}`, "ok"); return; }
  renderPaySuccess();
}

function renderPaySuccess() {
  PM.stage = "success";
  $("#payCard").innerHTML = `
    <div class="success">
      <div class="tick">✓</div>
      <h2>Payment received</h2>
      <p class="qr-amount">${inr(PM.total)}</p>
      <p class="kv">Invoice <b>${esc(PM.invoice || "")}</b></p>
      <p class="kv">Paid by <b>${esc(PM.method || "UPI")}</b></p>
      <div class="stack" style="margin-top:16px">
        <a class="btn primary" href="/receipt/${encodeURIComponent(PM.invoice || "")}" target="_blank" rel="noopener">View receipt</a>
        <button class="btn" id="payDone">Done</button>
      </div>
    </div>`;
  $("#payDone").onclick = () => { closePay(); PM.stage = "bill"; showTab("payments"); };
}

// ------------------------------------------------------------ payments & receipts tab
async function refreshHistory() {
  try {
    const [h, st] = await Promise.all([api("/api/history"), api("/api/stats")]);
    $("#summary").innerHTML = `
      <div><span>Total spent</span><b>${inr(st.spent)}</b></div>
      <div><span>Charging sessions</span><b>${st.sessions}</b></div>
      <div><span>Energy used</span><b>${st.kwh} kWh</b></div>
      <div><span>Distance added*</span><b>${st.km} km</b></div>
      <div><span>Most used station</span><b class="small-b">${esc(st.top_station || "-")}</b></div>`;
    $("#historyList").innerHTML = h.items.length
      ? `<div class="table-wrap"><table class="grid">
          <thead><tr><th>Invoice</th><th>Date</th><th>Station</th><th>Vehicle</th><th class="r">Energy</th><th>Paid by</th><th class="r">Total</th><th></th></tr></thead>
          <tbody>${h.items.map((r) => `<tr>
            <td>${esc(r.invoice)}</td><td>${esc(niceDate(r.date))}</td>
            <td>${esc(r.station)}<span class="sub">${esc(r.city)}</span></td><td>${esc(r.vehicle)}</td>
            <td class="r">${Number(r.energy_kwh).toFixed(2)} kWh</td><td><span class="method">${esc(r.method)}</span></td>
            <td class="r"><b>${inr(r.total)}</b></td>
            <td><a href="/receipt/${encodeURIComponent(r.invoice)}" target="_blank" rel="noopener">Receipt</a></td></tr>`).join("")}</tbody>
        </table></div><p class="note" style="margin-top:8px">* Estimated at about 6 km per kWh.</p>`
      : `<div class="empty"><h3>No payments yet</h3><p>Receipts for your paid charging sessions will be listed here.</p></div>`;
  } catch (e) { /* ignore, the next refresh will try again */ }
}

// ------------------------------------------------------------ issues
const PRIORITY_LABEL = { low: "Low", medium: "Medium", high: "High" };

async function refreshIssues(quiet) {
  try {
    const d = await api("/api/issues?scope=" + S.issueScope);
    S.issues = d.items;
    if (!S.issueMeta) S.issueMeta = await api("/api/issues/meta");
    if (!quiet || S.tab === "issues") renderIssues();
    // the badge always shows the user's own unresolved reports
    const mine = S.issueScope === "mine" ? d.items : (await api("/api/issues?scope=mine")).items;
    setCount("[data-issues-count]", mine.filter((i) => i.status === "open" || i.status === "in_progress").length);
    $("#issueCounts").innerHTML = ["open", "in_progress", "resolved", "closed"]
      .map((k) => `<span>${S.issueMeta.statuses[k]}: <b>${d.counts[k]}</b></span>`).join("");
  } catch (e) { if (!quiet) toast(e.message, "bad"); }
}

function renderIssues() {
  const want = $("#issueStatus").value;
  const rows = S.issues.filter((i) => !want || i.status === want);
  const all = S.issueScope === "all";
  $("#issuesNote").textContent = all
    ? "Showing reports from every driver. Open one to reply or change its status."
    : "Report a problem at a charging station and follow it until it is fixed.";
  if (!rows.length) {
    $("#issueTable").innerHTML = `<div class="empty"><h3>${S.issues.length ? "No issues with that status" : "No issues reported"}</h3>
      <p>${S.issues.length ? "Change the status filter to see the others." : "If something is wrong at a charging station, report it and we will keep you updated here."}</p>
      ${S.issues.length ? "" : `<button class="btn primary" onclick="openIssueForm()">Report an issue</button>`}</div>`;
    return;
  }
  $("#issueTable").innerHTML = `<div class="table-wrap"><table class="grid">
    <thead><tr><th>ID</th><th>Issue</th><th>Station</th><th>Priority</th><th>Status</th><th>Last update</th></tr></thead>
    <tbody>${rows.map((i) => `<tr class="click" data-act="issue" data-id="${esc(i.id)}">
      <td>${esc(i.id)}</td>
      <td><b>${esc(i.title)}</b><span class="sub">${esc(i.category_label)}${all ? " &middot; by " + esc(i.reporter) : ""}</span></td>
      <td>${esc(i.station)}<span class="sub">${esc(i.city)}${i.slot ? " &middot; " + esc(i.slot) : ""}</span></td>
      <td><span class="prio ${i.priority}">${PRIORITY_LABEL[i.priority]}</span></td>
      <td><span class="status ${i.status}">${esc(i.status_label)}</span></td>
      <td>${esc(niceDate(i.updated))}</td></tr>`).join("")}</tbody></table></div>`;
}

function closeIssueModal() { $("#issueModal").classList.remove("show"); }

async function openIssueForm(pre = {}) {
  if (!S.issueMeta) { try { S.issueMeta = await api("/api/issues/meta"); } catch (e) { return toast(e.message, "bad"); } }
  const m = S.issueMeta;
  const stationId = pre.station_id || S.drawerId || (visibleStations()[0] || S.stations[0]).id;
  closeDrawer();
  const byCity = S.cities.map((c) => `<optgroup label="${esc(c.name)}">${S.stations.filter((s) => s.city === c.name)
    .map((s) => `<option value="${s.id}" ${s.id === stationId ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</optgroup>`).join("");
  $("#issueCard").innerHTML = `
    <button class="x" aria-label="Close" id="issueX">&times;</button>
    <h2>Report an issue</h2>
    <p class="note" style="margin-bottom:14px">Tell us what is wrong. Station staff will see this and you can follow the progress under Issues.</p>
    <form id="issueForm">
      <div class="two">
        <div class="field"><label for="i-station">Station</label><select class="sel" id="i-station" style="width:100%">${byCity}</select></div>
        <div class="field"><label for="i-slot">Slot</label><select class="sel" id="i-slot" style="width:100%"></select></div>
      </div>
      <div class="two">
        <div class="field"><label for="i-cat">Type of problem</label><select class="sel" id="i-cat" style="width:100%">
          ${Object.entries(m.categories).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("")}</select></div>
        <div class="field"><label for="i-prio">How urgent is it?</label><select class="sel" id="i-prio" style="width:100%">
          <option value="low">Low, can wait</option><option value="medium" selected>Medium</option><option value="high">High, blocking me or unsafe</option></select></div>
      </div>
      <div class="field"><label for="i-title">Short title</label><input class="input" id="i-title" maxlength="80" placeholder="e.g. Slot 3 cable will not lock" required></div>
      <div class="field"><label for="i-desc">What happened?</label><textarea class="input" id="i-desc" maxlength="1000" placeholder="Describe the problem and when you noticed it." required></textarea></div>
      <p class="form-error" id="issueErr" role="alert"></p>
      <div class="row-actions">
        <button class="btn primary" type="submit">Submit report</button>
        <button class="btn" type="button" id="issueCancel">Cancel</button>
      </div>
    </form>`;
  const fillSlots = () => {
    const st = S.byId[$("#i-station").value];
    $("#i-slot").innerHTML = `<option value="">Not sure / whole station</option>` +
      st.slots.map((s) => `<option value="${esc(s.label)}" ${s.label === pre.slot ? "selected" : ""}>${esc(s.label)} (${s.power} kW)</option>`).join("");
  };
  fillSlots();
  $("#i-station").onchange = () => { pre = {}; fillSlots(); };
  $("#issueX").onclick = $("#issueCancel").onclick = closeIssueModal;
  $("#issueForm").onsubmit = async (e) => {
    e.preventDefault();
    try {
      await api("/api/issues", { body: {
        station_id: $("#i-station").value, slot: $("#i-slot").value, category: $("#i-cat").value,
        priority: $("#i-prio").value, title: $("#i-title").value, description: $("#i-desc").value } });
      closeIssueModal();
      toast("Issue reported. You can follow it under Issues.", "ok");
      showTab("issues");
    } catch (er) { $("#issueErr").textContent = er.message; }
  };
  $("#issueModal").classList.add("show");
  setTimeout(() => $("#i-title").focus(), 30);
}

async function openIssue(id) {
  try {
    const { issue } = await api("/api/issues/" + encodeURIComponent(id));
    renderIssueDetail(issue);
    $("#issueModal").classList.add("show");
  } catch (e) { toast(e.message, "bad"); }
}

function renderIssueDetail(i) {
  const staffView = S.user.is_admin;
  const closed = i.status === "closed";
  let statusControls = "";
  if (staffView) {
    statusControls = `<div class="field" style="margin-top:14px"><label for="i-newstatus">Update status</label>
      <div class="row-actions" style="margin-top:0">
        <select class="sel" id="i-newstatus">${Object.entries(S.issueMeta.statuses).map(([k, v]) => `<option value="${k}" ${k === i.status ? "selected" : ""}>${esc(v)}</option>`).join("")}</select>
        <input class="input" id="i-note" placeholder="Note for the driver (optional)" maxlength="600" style="flex:1;min-width:160px;width:auto">
        <button class="btn primary" id="i-setstatus">Save</button>
      </div></div>`;
  } else if (i.mine) {
    statusControls = `<div class="row-actions">${closed || i.status === "resolved"
      ? `<button class="btn" id="i-reopen">Reopen this issue</button>` : ""}${closed ? "" : `<button class="btn" id="i-close">${i.status === "resolved" ? "Confirm fixed and close" : "Close this issue"}</button>`}</div>`;
  }
  $("#issueCard").innerHTML = `
    <button class="x" aria-label="Close" id="issueX">&times;</button>
    <h2>${esc(i.title)}</h2>
    <div class="muted">${esc(i.id)} &middot; <span class="status ${i.status}">${esc(i.status_label)}</span></div>
    <div class="detail-grid">
      <div><span>Station</span>${esc(i.station)}, ${esc(i.city)}</div>
      <div><span>Slot</span>${esc(i.slot || "Not specified")}</div>
      <div><span>Type</span>${esc(i.category_label)}</div>
      <div><span>Priority</span>${esc(PRIORITY_LABEL[i.priority])}</div>
      <div><span>Reported by</span>${esc(i.reporter)}</div>
      <div><span>Reported on</span>${esc(niceDate(i.created))}</div>
    </div>
    <div class="desc-box">${esc(i.description)}</div>
    ${statusControls}
    <div class="h-sec">Activity</div>
    <ul class="timeline">${i.updates.map((u) => `<li class="${u.role}"><div class="when">${esc(niceDate(u.at))} &middot; ${esc(u.by)}${u.role === "staff" ? " (station staff)" : ""}</div>${esc(u.text)}</li>`).join("")}</ul>
    ${closed ? "" : `<div class="field" style="margin-top:6px"><label for="i-comment">Add a comment</label>
      <textarea class="input" id="i-comment" maxlength="600" style="min-height:60px"></textarea></div>
      <button class="btn" id="i-post">Post comment</button>`}`;
  $("#issueX").onclick = closeIssueModal;
  const act = async (path, body) => {
    try {
      const r = await api(`/api/issues/${encodeURIComponent(i.id)}/${path}`, { body });
      renderIssueDetail(r.issue);
      refreshIssues();
    } catch (e) { toast(e.message, "bad"); }
  };
  if ($("#i-post")) $("#i-post").onclick = () => act("comment", { text: $("#i-comment").value });
  if ($("#i-setstatus")) $("#i-setstatus").onclick = () => act("status", { status: $("#i-newstatus").value, note: $("#i-note").value });
  if ($("#i-close")) $("#i-close").onclick = () => act("status", { status: "closed" });
  if ($("#i-reopen")) $("#i-reopen").onclick = () => act("status", { status: "open", note: "Issue reopened." });
}

// the empty-state button in the issues table uses an inline handler
window.openIssueForm = openIssueForm;

setInterval(() => { if (S.user) refreshIssues(true); }, 20000);

start();
