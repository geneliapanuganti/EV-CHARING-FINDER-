"""
Electric Vehicle Charging Station Slot Booking & Issue Tracking App
===================================================================
Flask backend.   Run:  python app.py   ->  http://127.0.0.1:5050

What it does
  * OTP login (mobile or email), see auth.py
  * 24 charging stations in 6 cities, shown on Google Maps
  * slot booking with a hold timer, charging / idle timers and 4 part billing
  * UPI QR payment through Razorpay (or a built in demo QR), promo codes, receipts
  * issue tracking for problems at a station, see issues.py
  * no-show fines: Rs 100 when a booked slot is never started, account blocked after 5
"""

import hashlib
import hmac
import html
import math
import os
import random
import re
import threading
import time
import uuid
import webbrowser
from datetime import datetime

import requests
from flask import Flask, Response, abort, g, jsonify, request, send_from_directory

import auth
import issues
from auth import login_required
from common import BASE_DIR, err, read_json, write_json

try:  # only used to draw the demo QR; real Razorpay QR images come from Razorpay
    import segno
except ImportError:  # pragma: no cover
    segno = None


# --------------------------------------------------------------------------
# Settings & pricing
# --------------------------------------------------------------------------
ELECTRICITY_RATE = 60.0   # Rs per kWh
CHARGING_RATE = 2.0       # Rs per minute of charging
IDLE_RATE = 5.0           # Rs per minute idle (plugged in, not charging)
FIXED_RATE = 20.0         # Rs fixed station fee
HOLD_MINUTES = 15         # booking is held this long before it expires

HISTORY_FILE = os.path.join(BASE_DIR, "ev_billing_history.json")
RECEIPT_DIR = os.path.join(BASE_DIR, "receipts")

RZP_KEY_ID = os.getenv("RAZORPAY_KEY_ID", "").strip()
RZP_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET", "").strip()
RZP_WEBHOOK_SECRET = os.getenv("RAZORPAY_WEBHOOK_SECRET", "").strip()
RZP_ENABLED = bool(RZP_KEY_ID and RZP_KEY_SECRET)
RZP_API = "https://api.razorpay.com/v1"

GOOGLE_MAPS_KEY = os.getenv("GOOGLE_MAPS_API_KEY", "").strip()
GOOGLE_MAP_ID = os.getenv("GOOGLE_MAP_ID", "").strip() or "DEMO_MAP_ID"
MAX_ACTIVE_PER_USER = 3   # bookings one person can hold at once
QR_VALID_SECONDS = 600    # a payment QR is valid for 10 real minutes

APP_NAME = "Electric Vehicle Charging Station Slot Booking & Issue Tracking App"

SPEEDS = [1, 10, 60, 300]  # simulated seconds per real second

EV_MODELS = [
    {"name": "Tata Tiago EV", "kwh": 24.0},
    {"name": "Tata Nexon EV", "kwh": 40.5},
    {"name": "Mahindra XUV400", "kwh": 39.4},
    {"name": "MG ZS EV", "kwh": 50.3},
    {"name": "BYD Atto 3", "kwh": 60.5},
    {"name": "Hyundai Ioniq 5", "kwh": 72.6},
    {"name": "Ather 450X (scooter)", "kwh": 3.7},
    {"name": "Custom battery", "kwh": 40.0},
]

PROMOS = {
    "SAVE10": "10% off the bill (max Rs 100)",
    "FIRSTCHARGE": "Rs 50 off your very first charge",
    "EV25": "Rs 25 off on bills of Rs 150 or more",
}

# --------------------------------------------------------------------------
# Stations: city -> centre + stations (names are sample data)
# --------------------------------------------------------------------------
SLOT_PROFILES = {
    "standard": [("Type 2 AC", 7.4), ("Type 2 AC", 11.0), ("CCS2 DC", 30.0), ("CCS2 DC", 50.0)],
    "turbo": [("Type 2 AC", 11.0), ("CCS2 DC", 30.0), ("CCS2 DC", 60.0), ("CCS2 DC", 120.0)],
}

CITIES = {
    "Hyderabad": {
        "center": [17.4239, 78.4738], "state": "Telangana",
        "stations": [
            ("Hitech City Fast Hub", "Cyber Towers Road, Madhapur, Hyderabad, Telangana 500081",
             17.4435, 78.3772, "turbo", 4.8, ["Cafe", "Restroom", "WiFi", "Covered"]),
            ("Banjara Hills Charge Point", "Road No. 12, Banjara Hills, Hyderabad, Telangana 500034",
             17.4126, 78.4482, "standard", 4.5, ["Cafe", "Restroom", "Valet"]),
            ("Gachibowli EV Plaza", "Financial District, Nanakramguda, Hyderabad, Telangana 500032",
             17.4170, 78.3420, "turbo", 4.7, ["Food court", "WiFi", "Restroom", "Covered"]),
            ("Jubilee Hills Charging Stop", "Road No. 36, Jubilee Hills, Hyderabad, Telangana 500033",
             17.4326, 78.4071, "standard", 4.4, ["Cafe", "Restroom"]),
        ],
    },
    "Bengaluru": {
        "center": [12.9716, 77.5946], "state": "Karnataka",
        "stations": [
            ("Koramangala Power Stop", "5th Block, Koramangala, Bengaluru, Karnataka 560095",
             12.9352, 77.6245, "turbo", 4.8, ["Cafe", "WiFi", "Restroom"]),
            ("Whitefield Charge Hub", "ITPL Main Road, Whitefield, Bengaluru, Karnataka 560066",
             12.9866, 77.7370, "turbo", 4.6, ["Food court", "Restroom", "Covered"]),
            ("Indiranagar EV Point", "100 Feet Road, Indiranagar, Bengaluru, Karnataka 560038",
             12.9784, 77.6408, "standard", 4.5, ["Cafe", "WiFi"]),
            ("HSR Layout Juice Bar", "27th Main Road, HSR Layout, Bengaluru, Karnataka 560102",
             12.9116, 77.6389, "standard", 4.3, ["Cafe", "Restroom"]),
        ],
    },
    "Mumbai": {
        "center": [19.0760, 72.8777], "state": "Maharashtra",
        "stations": [
            ("Bandra Kurla Charge Hub", "G Block, BKC, Bandra East, Mumbai, Maharashtra 400051",
             19.0653, 72.8697, "turbo", 4.8, ["Cafe", "Restroom", "WiFi", "Covered"]),
            ("Andheri Fast Charge", "Veera Desai Road, Andheri West, Mumbai, Maharashtra 400053",
             19.1319, 72.8330, "standard", 4.4, ["Food court", "Restroom"]),
            ("Powai Lake EV Station", "Hiranandani Gardens, Powai, Mumbai, Maharashtra 400076",
             19.1176, 72.9060, "standard", 4.6, ["Cafe", "WiFi", "Restroom"]),
            ("Lower Parel Charging Deck", "Senapati Bapat Marg, Lower Parel, Mumbai, Maharashtra 400013",
             18.9930, 72.8258, "turbo", 4.5, ["Cafe", "Valet", "Covered"]),
        ],
    },
    "Delhi": {
        "center": [28.6139, 77.2090], "state": "Delhi NCR",
        "stations": [
            ("Connaught Place Charger", "Barakhamba Road, Connaught Place, New Delhi 110001",
             28.6315, 77.2167, "standard", 4.5, ["Cafe", "Restroom", "WiFi"]),
            ("Saket Mall EV Point", "Select Citywalk, Saket, New Delhi 110017",
             28.5285, 77.2197, "turbo", 4.7, ["Food court", "Restroom", "Covered", "WiFi"]),
            ("Dwarka Sector 21 Hub", "Near Metro Station, Sector 21, Dwarka, New Delhi 110075",
             28.5524, 77.0584, "standard", 4.3, ["Restroom"]),
            ("Aerocity Fast Lane", "Asset Area, Aerocity, New Delhi 110037",
             28.5562, 77.1199, "turbo", 4.6, ["Cafe", "WiFi", "Restroom", "Covered"]),
        ],
    },
    "Chennai": {
        "center": [13.0827, 80.2707], "state": "Tamil Nadu",
        "stations": [
            ("T. Nagar Charge Point", "Usman Road, T. Nagar, Chennai, Tamil Nadu 600017",
             13.0418, 80.2341, "standard", 4.4, ["Food court", "Restroom"]),
            ("OMR Tech Park EV Hub", "Old Mahabalipuram Road, Sholinganallur, Chennai, Tamil Nadu 600119",
             12.9010, 80.2279, "turbo", 4.7, ["Cafe", "WiFi", "Restroom", "Covered"]),
            ("Anna Nagar Fast Charge", "2nd Avenue, Anna Nagar, Chennai, Tamil Nadu 600040",
             13.0850, 80.2101, "standard", 4.5, ["Cafe", "Restroom"]),
            ("Adyar Riverside Charger", "Lattice Bridge Road, Adyar, Chennai, Tamil Nadu 600020",
             13.0012, 80.2565, "standard", 4.3, ["Cafe", "WiFi"]),
        ],
    },
    "Pune": {
        "center": [18.5204, 73.8567], "state": "Maharashtra",
        "stations": [
            ("Hinjewadi EV Hub", "Phase 1, Rajiv Gandhi Infotech Park, Hinjewadi, Pune 411057",
             18.5912, 73.7389, "turbo", 4.6, ["Food court", "Restroom", "Covered"]),
            ("Koregaon Park Charger", "North Main Road, Koregaon Park, Pune, Maharashtra 411001",
             18.5362, 73.8940, "standard", 4.7, ["Cafe", "WiFi", "Restroom"]),
            ("Viman Nagar Power Stop", "Near Phoenix Marketcity, Viman Nagar, Pune, Maharashtra 411014",
             18.5679, 73.9143, "turbo", 4.5, ["Food court", "Restroom", "Covered", "WiFi"]),
            ("Baner Charging Point", "Baner Road, Baner, Pune, Maharashtra 411045",
             18.5590, 73.7868, "standard", 4.4, ["Cafe", "Restroom"]),
        ],
    },
}

STATE_TEXT = {
    "BOOKED": "Booked",
    "CHARGING": "Charging",
    "IDLE": "Idle (plugged in)",
    "PAYMENT": "Payment due",
}


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def fmt_hms(seconds):
    seconds = max(0, int(seconds))
    return f"{seconds // 3600:02d}:{(seconds % 3600) // 60:02d}:{seconds % 60:02d}"


def billable_minutes(seconds):
    """Whole minutes, rounded up (any started minute counts)."""
    if seconds <= 0:
        return 0
    return int(math.ceil(round(seconds / 60.0, 6)))


def money(x):
    return f"Rs {x:,.2f}"


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def promo_discount(code, subtotal):
    """Discount for a promo code on a given subtotal (0 if not applicable)."""
    if code == "SAVE10":
        return round(min(subtotal * 0.10, 100.0), 2)
    if code == "FIRSTCHARGE":
        return 50.0
    if code == "EV25":
        return 25.0 if subtotal >= 150 else 0.0
    return 0.0


# --------------------------------------------------------------------------
# Domain model
# --------------------------------------------------------------------------
class Session:
    """One customer's booking -> charging -> idle -> payment lifecycle.
    All times are on the app's simulated clock (seconds)."""

    def __init__(self, owner, customer, vehicle, ev_model, capacity, start_soc, target_soc,
                 power_kw, now):
        self.id = uuid.uuid4().hex[:10]
        self.owner = owner
        self.customer = customer
        self.vehicle = vehicle
        self.ev_model = ev_model
        self.capacity = float(capacity)
        self.start_soc = int(start_soc)
        self.target_soc = int(target_soc)
        self.needed = round(self.capacity * (self.target_soc - self.start_soc) / 100.0, 2)
        self.power = float(power_kw)
        self.state = "BOOKED"
        self.book_time = now
        self.expires = now + HOLD_MINUTES * 60
        self.charge_start = None
        self.charge_end = None
        self.idle_start = None
        self.idle_end = None
        self.energy = 0.0
        self.bill = None
        self.promo = None
        self.fine_due = 0.0   # no-show fines added to this bill when unplugged
        self.station = None
        self.slot = None

    # ---- timing ----
    def charge_seconds(self, now):
        if self.charge_start is None:
            return 0.0
        end = self.charge_end if self.charge_end is not None else now
        return max(0.0, end - self.charge_start)

    def idle_seconds(self, now):
        if self.idle_start is None:
            return 0.0
        end = self.idle_end if self.idle_end is not None else now
        return max(0.0, end - self.idle_start)

    def current_energy(self, now):
        if self.state == "CHARGING":
            return min(self.needed, self.power * self.charge_seconds(now) / 3600.0)
        return self.energy

    def soc(self, now):
        e = self.current_energy(now)
        return min(100.0, self.start_soc + (e / self.capacity * 100.0 if self.capacity else 0))

    # ---- transitions ----
    def start_charging(self, now):
        self.state = "CHARGING"
        self.charge_start = now

    def stop_charging(self, now):
        self.energy = self.current_energy(now)
        self.charge_end = now
        self.idle_start = now
        self.state = "IDLE"

    def update(self, now):
        """Advance the session. Returns 'expired', 'charged' or None."""
        if self.state == "BOOKED" and now >= self.expires:
            self.state = "EXPIRED"
            return "expired"
        if self.state == "CHARGING":
            kwh = self.power * (now - self.charge_start) / 3600.0
            if kwh >= self.needed:
                # idle time starts exactly when the target energy was reached
                self.energy = self.needed
                self.charge_end = self.charge_start + self.needed / self.power * 3600.0
                self.idle_start = self.charge_end
                self.state = "IDLE"
                return "charged"
            self.energy = kwh
        return None

    # ---- billing ----
    def compute_bill(self, now):
        energy = round(self.current_energy(now), 2)
        c_min = billable_minutes(self.charge_seconds(now))
        i_min = billable_minutes(self.idle_seconds(now))
        b = {
            "energy_kwh": energy,
            "charge_minutes": c_min,
            "idle_minutes": i_min,
            "electricity_cost": round(energy * ELECTRICITY_RATE, 2),
            "charging_cost": round(c_min * CHARGING_RATE, 2),
            "idle_cost": round(i_min * IDLE_RATE, 2),
            "fixed_cost": FIXED_RATE,
        }
        b["subtotal"] = round(
            b["electricity_cost"] + b["charging_cost"] + b["idle_cost"] + b["fixed_cost"], 2
        )
        disc = promo_discount(self.promo, b["subtotal"]) if self.promo else 0.0
        disc = min(disc, max(0.0, b["subtotal"] - 1.0))  # a payable bill is always >= Rs 1
        b["promo"] = self.promo if disc > 0 else None
        b["discount"] = round(disc, 2)
        b["fine_cost"] = round(self.fine_due, 2)   # no-show fines are never discounted
        b["total"] = round(b["subtotal"] - b["discount"] + b["fine_cost"], 2)
        return b

    def unplug(self, now):
        """Stop everything and freeze the bill."""
        if self.state == "CHARGING":
            self.stop_charging(now)
        if self.idle_start is not None:
            self.idle_end = now
        self.state = "PAYMENT"
        self.fine_due = unclaimed_fine(self.owner)
        self.bill = self.compute_bill(now)

    def to_dict(self, now):
        b = self.bill if self.bill else self.compute_bill(now)
        needed = self.needed or 0.0001
        return {
            "id": self.id,
            "state": self.state,
            "state_text": STATE_TEXT.get(self.state, self.state),
            "customer": self.customer,
            "vehicle": self.vehicle,
            "ev_model": self.ev_model,
            "start_soc": self.start_soc,
            "target_soc": self.target_soc,
            "soc": round(self.soc(now), 1),
            "needed": self.needed,
            "power": self.power,
            "progress": round(min(1.0, self.current_energy(now) / needed), 4),
            "hold_left": max(0, int(self.expires - now)) if self.state == "BOOKED" else 0,
            "hold_total": HOLD_MINUTES * 60,
            "charge_seconds": int(self.charge_seconds(now)),
            "idle_seconds": int(self.idle_seconds(now)),
            "bill": b,
            "promo": self.promo,
            "station_id": self.station.id,
            "station_name": self.station.name,
            "station_address": self.station.address,
            "city": self.station.city,
            "lat": self.station.lat,
            "lng": self.station.lng,
            "slot_idx": self.station.slots.index(self.slot),
            "slot_label": self.slot.label,
            "connector": self.slot.connector,
        }


class Slot:
    def __init__(self, label, connector, power):
        self.label = label
        self.connector = connector
        self.power = power
        self.session = None

    @property
    def free(self):
        return self.session is None


class Station:
    def __init__(self, city, row):
        name, address, lat, lng, profile, rating, amenities = row
        self.id = slugify(f"{city}-{name}")
        self.city = city
        self.name = name
        self.address = address
        self.lat = lat
        self.lng = lng
        self.profile = profile
        self.rating = rating
        self.amenities = amenities
        self.slots = [
            Slot(f"Slot {i + 1}", conn, kw) for i, (conn, kw) in enumerate(SLOT_PROFILES[profile])
        ]

    def static_dict(self):
        return {
            "id": self.id, "city": self.city, "name": self.name, "address": self.address,
            "lat": self.lat, "lng": self.lng, "rating": self.rating,
            "amenities": self.amenities, "hours": "Open 24x7",
            "slots": [{"idx": i, "label": s.label, "connector": s.connector, "power": s.power}
                      for i, s in enumerate(self.slots)],
            "max_power": max(s.power for s in self.slots),
        }


# --------------------------------------------------------------------------
# Storage
# --------------------------------------------------------------------------
def load_history():
    return read_json(HISTORY_FILE, [])


def save_history(history):
    return write_json(HISTORY_FILE, history)


def receipt_text(r):
    line = "=" * 46

    def row(label, amount):
        return f"{label:<32}{money(amount):>14}"

    out = [
        line,
        "     EV CHARGING STATION - INVOICE",
        line,
        f"Invoice No   : {r['invoice']}",
        f"Transaction  : {r['txn']}",
        f"Date         : {r['date']}",
        f"City         : {r['city']}",
        f"Station      : {r['station']}",
        f"Slot         : {r['slot']} ({r['connector']}, {r['power_kw']} kW)",
        f"Customer     : {r['customer']}",
        f"Vehicle      : {r['vehicle']}",
        "-" * 46,
        f"Energy delivered      : {r['energy_kwh']:.2f} kWh",
        f"Charging time         : {r['charge_minutes']} min",
        f"Idle time             : {r['idle_minutes']} min",
        "-" * 46,
        row(f"Electricity ({r['energy_kwh']:.2f} kWh x Rs {ELECTRICITY_RATE:g})", r["electricity_cost"]),
        row(f"Charging ({r['charge_minutes']} min x Rs {CHARGING_RATE:g})", r["charging_cost"]),
        row(f"Idle ({r['idle_minutes']} min x Rs {IDLE_RATE:g})", r["idle_cost"]),
        row("Fixed station fee", r["fixed_cost"]),
    ]
    if r.get("discount"):
        out.append(row(f"Promo {r.get('promo') or ''}", -r["discount"]))
    if r.get("fine_cost"):
        out.append(row("No-show fines", r["fine_cost"]))
    out += [
        "-" * 46,
        row("TOTAL AMOUNT PAID", r["total"]),
        f"Payment method                : {r['method']}",
    ]
    if r.get("payment_id"):
        out.append(f"Razorpay payment id           : {r['payment_id']}")
    out += [line, "        Thank you for charging with us.", line]
    return "\n".join(out)


# --------------------------------------------------------------------------
# World state (single process, guarded by one lock)
# --------------------------------------------------------------------------
LOCK = threading.RLock()
STATIONS = {}
for _city, _info in CITIES.items():
    for _row in _info["stations"]:
        _s = Station(_city, _row)
        STATIONS[_s.id] = _s

HISTORY = load_history()
PAYMENTS = {}      # qr_id -> payment dict
EVENTS = []        # recent notifications for the UI
_event_seq = 0
SIM = 0.0          # simulated clock (seconds)
SPEED = 60
_last_real = time.monotonic()


def unclaimed_fine(uid):
    """Pending fines of a user that aren't already on one of their unpaid bills."""
    held = sum(sl.session.fine_due for stn in STATIONS.values() for sl in stn.slots
               if sl.session and sl.session.owner == uid and sl.session.state == "PAYMENT")
    return round(max(0.0, auth.pending_fine(uid) - held), 2)


def push_event(kind, message, user=None):
    global _event_seq
    _event_seq += 1
    EVENTS.append({"id": _event_seq, "kind": kind, "message": message, "user": user})
    del EVENTS[:-30]


def advance():
    """Move the simulated clock forward and tick every session."""
    global SIM, _last_real
    real = time.monotonic()
    SIM += (real - _last_real) * SPEED
    _last_real = real
    for stn in STATIONS.values():
        for sl in stn.slots:
            s = sl.session
            if not s:
                continue
            ev = s.update(SIM)
            if ev == "expired":
                sl.session = None
                acct = auth.add_no_show(s.owner, stn.name, sl.label, SIM)
                if acct and acct["blocked"]:
                    push_event("bad", f"No-show at {stn.name} ({sl.label}). Fine of Rs {auth.NO_SHOW_FINE:g} added. "
                                      f"That was no-show {acct['strikes']} of {acct['max_strikes']}, so your account "
                                      f"is now blocked from new bookings.", s.owner)
                elif acct:
                    left = acct["max_strikes"] - acct["strikes"]
                    push_event("bad", f"You didn't start charging at {stn.name} ({sl.label}) within {HOLD_MINUTES} min. "
                                      f"Fine of Rs {auth.NO_SHOW_FINE:g} added to your next bill. "
                                      f"No-show {acct['strikes']} of {acct['max_strikes']}: "
                                      f"{left} more and your account is blocked.", s.owner)
                else:
                    push_event("warn", f"Booking at {stn.name} ({sl.label}) expired.", s.owner)
            elif ev == "charged":
                push_event("ok", f"Charging complete. {s.customer}, please unplug from {stn.name} / {sl.label} "
                                 f"- idle fee of Rs {IDLE_RATE:g}/min has started.", s.owner)


def find_session(sid):
    for stn in STATIONS.values():
        for sl in stn.slots:
            if sl.session and sl.session.id == sid:
                return stn, sl, sl.session
    return None, None, None


def finalize_payment(stn, sl, s, method, payment_id=None):
    """Turn a paid session into an invoice, free the slot. Returns the record."""
    b = s.bill
    n = len(HISTORY) + 1
    rec = {
        "invoice": f"INV-{n:05d}",
        "txn": "TXN" + datetime.now().strftime("%y%m%d%H%M%S") + str(random.randint(100, 999)),
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "city": stn.city, "station": stn.name, "address": stn.address, "slot": sl.label,
        "connector": sl.connector, "power_kw": sl.power,
        "user": s.owner, "customer": s.customer, "vehicle": s.vehicle, "ev_model": s.ev_model,
        "start_soc": s.start_soc, "target_soc": s.target_soc, "method": method,
    }
    if payment_id:
        rec["payment_id"] = payment_id
    rec.update(b)
    HISTORY.append(rec)
    saved = save_history(HISTORY)
    try:
        os.makedirs(RECEIPT_DIR, exist_ok=True)
        with open(os.path.join(RECEIPT_DIR, rec["invoice"] + ".txt"), "w", encoding="utf-8") as f:
            f.write(receipt_text(rec))
    except OSError:
        saved = False
    auth.settle_fine(s.owner, b.get("fine_cost", 0.0))
    sl.session = None
    push_event("ok", f"Payment of {money(rec['total'])} received via {method}. Invoice {rec['invoice']} is ready.", s.owner)
    rec["_saved"] = saved
    return rec


# --------------------------------------------------------------------------
# Razorpay (UPI QR) + DEMO mode
# --------------------------------------------------------------------------
class PaymentError(Exception):
    pass


def rzp_request(method, path, **kw):
    try:
        r = requests.request(method, RZP_API + path, auth=(RZP_KEY_ID, RZP_KEY_SECRET),
                             timeout=15, **kw)
    except requests.RequestException as exc:
        raise PaymentError(f"Could not reach Razorpay: {exc}") from exc
    try:
        data = r.json()
    except ValueError:
        data = {}
    if r.status_code >= 400:
        desc = (data.get("error") or {}).get("description") or f"Razorpay error {r.status_code}"
        raise PaymentError(desc)
    return data


def demo_qr_image(upi_link):
    if segno is None:
        return None
    try:
        qr = segno.make(upi_link, error="m")
        return qr.svg_data_uri(scale=8, border=2, dark="#14201b", light="#ffffff")
    except Exception:  # never let a cosmetic QR image break payments
        return None


def close_session_payments(sid):
    """Close any still-pending QR of a session (e.g. amount changed after a promo)."""
    for pid, p in PAYMENTS.items():
        if p["session_id"] == sid and p["status"] == "pending":
            p["status"] = "cancelled"
            if p["mode"] == "razorpay":
                try:
                    rzp_request("POST", f"/payments/qr_codes/{pid}/close")
                except PaymentError:
                    pass


def create_qr_payment(stn, sl, s):
    amount = s.bill["total"]
    paise = int(round(amount * 100))
    # re-use a still-valid QR for the same amount
    for pid, p in PAYMENTS.items():
        if (p["session_id"] == s.id and p["status"] == "pending" and p["amount_paise"] == paise
                and p["expires"] > time.time() + 20):
            return pid, p
    close_session_payments(s.id)
    expires = time.time() + QR_VALID_SECONDS
    if RZP_ENABLED:
        payload = {
            "type": "upi_qr",
            "name": "EV Charging Station",
            "usage": "single_use",
            "fixed_amount": True,
            "payment_amount": paise,
            "description": f"EV charging at {stn.name}"[:250],
            "close_by": int(expires),
            "notes": {"session_id": s.id, "station": stn.name, "vehicle": s.vehicle},
        }
        data = rzp_request("POST", "/payments/qr_codes", json=payload)
        pid, image, mode, upi = data["id"], data.get("image_url"), "razorpay", None
    else:
        pid = "demo_" + uuid.uuid4().hex[:12]
        upi = (f"upi://pay?pa=evcharging.demo@upi&pn=EV%20Charging%20Station&am={amount:.2f}"
               f"&cu=INR&tn=EV%20charging%20{s.vehicle}")
        image, mode = demo_qr_image(upi), "demo"
    p = {"session_id": s.id, "amount": amount, "amount_paise": paise, "status": "pending",
         "mode": mode, "image": image, "upi": upi, "expires": expires, "invoice": None,
         "created": time.time(), "owner": s.owner}
    PAYMENTS[pid] = p
    return pid, p


def payment_public(pid, p):
    return {
        "qr_id": pid, "status": p["status"], "mode": p["mode"], "amount": p["amount"],
        "image": p["image"], "upi": p["upi"],
        "seconds_left": max(0, int(p["expires"] - time.time())), "invoice": p["invoice"],
    }


def settle_payment(pid, p, payment_id=None):
    """Mark a QR payment paid and finalise the session (idempotent)."""
    if p["status"] == "paid":
        return
    stn, sl, s = find_session(p["session_id"])
    if not s or s.state != "PAYMENT":
        p["status"] = "paid"
        return
    method = "UPI (Razorpay QR)" if p["mode"] == "razorpay" else "UPI (Demo QR)"
    rec = finalize_payment(stn, sl, s, method, payment_id)
    p["status"] = "paid"
    p["invoice"] = rec["invoice"]


def refresh_payment(pid, p):
    """Poll Razorpay (or check the demo QR's expiry) and update our record."""
    if p["status"] != "pending":
        return
    if p["mode"] == "razorpay":
        data = rzp_request("GET", f"/payments/qr_codes/{pid}")
        got = int(data.get("payments_amount_received") or 0)
        if int(data.get("payments_count_received") or 0) >= 1 and got >= p["amount_paise"]:
            payment_id = None
            try:
                items = rzp_request("GET", f"/payments/qr_codes/{pid}/payments").get("items") or []
                payment_id = items[0]["id"] if items else None
            except (PaymentError, KeyError, IndexError):
                pass
            settle_payment(pid, p, payment_id)
            return
        if data.get("status") == "closed":
            p["status"] = "expired"
            return
    if time.time() > p["expires"]:
        p["status"] = "expired"


# --------------------------------------------------------------------------
# Flask app
# --------------------------------------------------------------------------
app = Flask(__name__, static_folder="static", static_url_path="/static")
app.json.sort_keys = False
auth.configure(app)
issues.init(STATIONS)
app.register_blueprint(issues.bp)


@app.before_request
def block_cross_site_posts():
    """Our own pages always send this header; a form on another website can't."""
    if request.method in ("POST", "PUT", "DELETE") and request.path.startswith("/api/") \
            and request.path != "/api/webhooks/razorpay":
        if request.headers.get("X-Requested-With") != "fetch":
            return err("Bad request.", 400)


@app.after_request
def no_cache_api(resp):
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/config")
def api_config():
    """Public bits the login page needs before anyone is logged in."""
    return jsonify({"app_name": APP_NAME,
                    "email_otp": auth.EMAIL_READY, "sms_otp": auth.SMS_READY})


@app.get("/api/bootstrap")
@login_required
def api_bootstrap():
    return jsonify({
        "maps": {"key": GOOGLE_MAPS_KEY, "map_id": GOOGLE_MAP_ID},
        "rates": {"electricity": ELECTRICITY_RATE, "charging": CHARGING_RATE,
                  "idle": IDLE_RATE, "fixed": FIXED_RATE, "hold_minutes": HOLD_MINUTES,
                  "fine": auth.NO_SHOW_FINE, "max_strikes": auth.MAX_NO_SHOWS},
        "payments": {"razorpay": RZP_ENABLED,
                     "mode": "razorpay" if RZP_ENABLED else "demo",
                     "test_key": RZP_KEY_ID.startswith("rzp_test_") if RZP_ENABLED else None},
        "speeds": SPEEDS,
        "ev_models": EV_MODELS,
        "promos": PROMOS,
        "cities": [{"name": n, "center": i["center"], "state": i["state"]}
                   for n, i in CITIES.items()],
        "stations": [s.static_dict() for s in STATIONS.values()],
    })


@app.get("/api/state")
@login_required
def api_state():
    with LOCK:
        advance()
        slots = {}
        for stn in STATIONS.values():
            slots[stn.id] = [
                {"st": sl.session.state if sl.session else "FREE"}
                for sl in stn.slots
            ]
        sessions = [sl.session.to_dict(SIM) for stn in STATIONS.values()
                    for sl in stn.slots if sl.session and sl.session.owner == g.user["id"]]
        after = request.args.get("after", type=int, default=0)
        return jsonify({
            "sim": int(SIM), "sim_hms": fmt_hms(SIM), "speed": SPEED,
            "slots": slots, "sessions": sessions, "account": auth.account_status(g.user),
            "events": [{"id": e["id"], "kind": e["kind"], "message": e["message"]}
                       for e in EVENTS if e["id"] > after and e["user"] in (None, g.user["id"])],
            "last_event": _event_seq,
        })


@app.post("/api/speed")
@login_required
def api_speed():
    global SPEED
    speed = (request.get_json(silent=True) or {}).get("speed")
    if speed not in SPEEDS:
        return err("Invalid speed.")
    with LOCK:
        advance()  # settle the clock at the old speed first
        SPEED = speed
    return jsonify({"speed": SPEED})


# ---- booking & session actions ----
@app.post("/api/book")
@login_required
def api_book():
    d = request.get_json(silent=True) or {}
    if auth.is_blocked(g.user["id"]):
        return err(f"Your account is blocked from new bookings after {auth.MAX_NO_SHOWS} no-shows. "
                   f"Please contact the station staff.", 403)
    stn = STATIONS.get(d.get("station_id"))
    if not stn:
        return err("Unknown station.", 404)
    try:
        sl = stn.slots[int(d.get("slot_idx"))]
    except (TypeError, ValueError, IndexError):
        return err("Pick a valid slot.")
    name = str(d.get("name", "")).strip()
    veh = re.sub(r"[\s\-]", "", str(d.get("vehicle", ""))).upper()
    if len(name) < 2 or len(name) > 40:
        return err("Enter your name (2-40 characters).")
    if not re.fullmatch(r"[A-Z0-9]{6,12}", veh):
        return err("Enter a valid vehicle number, e.g. TS09AB1234.")
    try:
        cap = float(d.get("capacity"))
        start, target = int(d.get("start_soc")), int(d.get("target_soc"))
    except (TypeError, ValueError):
        return err("Battery details look invalid.")
    if not (1 <= cap <= 150):
        return err("Battery capacity must be between 1 and 150 kWh.")
    if not (0 <= start <= 99) or not (1 <= target <= 100) or target <= start:
        return err("Target charge must be higher than the current charge.")
    ev_model = str(d.get("ev_model") or "Custom battery")[:40]
    with LOCK:
        advance()
        if sl.session is not None:
            return err("Someone just grabbed this slot. Pick another one!", 409)
        active = 0
        for other in STATIONS.values():
            for o in other.slots:
                if o.session and o.session.vehicle == veh:
                    return err(f"Vehicle {veh} already has an active booking.", 409)
                if o.session and o.session.owner == g.user["id"]:
                    active += 1
        if active >= MAX_ACTIVE_PER_USER:
            return err(f"You can hold up to {MAX_ACTIVE_PER_USER} bookings at a time.", 409)
        s = Session(g.user["id"], name, veh, ev_model, cap, start, target, sl.power, SIM)
        s.station, s.slot = stn, sl
        if s.needed < 0.1:
            return err("That's too small a top-up. Raise the target charge a bit.")
        sl.session = s
        return jsonify({"session": s.to_dict(SIM)})


def _get_session(sid):
    """Find one of the *logged in user's* sessions (others look like they don't exist)."""
    advance()
    stn, sl, s = find_session(sid)
    if s and s.owner != g.user["id"]:
        return None, None, None
    return stn, sl, s


@app.post("/api/session/<sid>/<action>")
@login_required
def api_session_action(sid, action):
    with LOCK:
        stn, sl, s = _get_session(sid)
        if not s:
            return err("Session not found (maybe it expired).", 404)
        if action == "start":
            if s.state != "BOOKED":
                return err("Only a booked slot can start charging.")
            s.start_charging(SIM)
        elif action == "stop":
            if s.state != "CHARGING":
                return err("Not charging right now.")
            s.stop_charging(SIM)
        elif action == "unplug":
            if s.state not in ("CHARGING", "IDLE"):
                return err("Nothing to unplug.")
            s.unplug(SIM)
        elif action == "cancel":
            if s.state != "BOOKED":
                return err("Only a booking that hasn't started can be cancelled.")
            sl.session = None
            return jsonify({"cancelled": True})
        else:
            return err("Unknown action.", 404)
        return jsonify({"session": s.to_dict(SIM)})


@app.post("/api/session/<sid>/promo")
@login_required
def api_promo(sid):
    code = str((request.get_json(silent=True) or {}).get("code", "")).strip().upper()
    with LOCK:
        stn, sl, s = _get_session(sid)
        if not s or s.state != "PAYMENT":
            return err("There's no bill to apply a promo to.", 404)
        if code == "":
            s.promo = None
        else:
            if code not in PROMOS:
                return err("That promo code doesn't exist.")
            if code == "FIRSTCHARGE" and any(r.get("user") == g.user["id"] for r in HISTORY):
                return err("FIRSTCHARGE is only valid on your very first charge.")
            if promo_discount(code, s.bill["subtotal"]) <= 0:
                return err("This promo doesn't apply to this bill (" + PROMOS[code] + ").")
            s.promo = code
        s.bill = s.compute_bill(SIM)
        close_session_payments(s.id)  # amount changed -> old QR is void
        return jsonify({"session": s.to_dict(SIM)})


# ---- payments ----
@app.post("/api/session/<sid>/pay/qr")
@login_required
def api_pay_qr(sid):
    with LOCK:
        stn, sl, s = _get_session(sid)
        if not s or s.state != "PAYMENT":
            return err("This bill is no longer payable.", 404)
        try:
            pid, p = create_qr_payment(stn, sl, s)
        except PaymentError as exc:
            return err(str(exc), 502)
        return jsonify(payment_public(pid, p))


def _my_payment(qr_id):
    p = PAYMENTS.get(qr_id)
    if not p:
        return None
    stn, sl, s = find_session(p["session_id"])
    if s and s.owner != g.user["id"]:
        return None
    if not s and p.get("owner") != g.user["id"]:
        return None
    return p


@app.get("/api/payments/<qr_id>")
@login_required
def api_payment_status(qr_id):
    with LOCK:
        advance()
        p = _my_payment(qr_id)
        if not p:
            return err("Unknown payment.", 404)
        try:
            refresh_payment(qr_id, p)
        except PaymentError as exc:
            out = payment_public(qr_id, p)
            out["warning"] = str(exc)
            return jsonify(out)
        return jsonify(payment_public(qr_id, p))


@app.post("/api/payments/<qr_id>/simulate")
@login_required
def api_payment_simulate(qr_id):
    """DEMO mode only: pretend the customer scanned and paid."""
    with LOCK:
        advance()
        p = _my_payment(qr_id)
        if not p or p["mode"] != "demo":
            return err("Simulation is only available in demo mode.", 403)
        if p["status"] != "pending":
            return err("This QR is no longer active.")
        settle_payment(qr_id, p)
        return jsonify(payment_public(qr_id, p))


@app.post("/api/session/<sid>/pay/cash")
@login_required
def api_pay_cash(sid):
    with LOCK:
        stn, sl, s = _get_session(sid)
        if not s or s.state != "PAYMENT":
            return err("This bill is no longer payable.", 404)
        close_session_payments(s.id)
        rec = finalize_payment(stn, sl, s, "Cash")
        return jsonify({"invoice": rec["invoice"], "total": rec["total"]})


@app.post("/api/webhooks/razorpay")
def api_webhook():
    """Optional: instant confirmation when the app is reachable from the internet."""
    raw = request.get_data()
    if not RZP_WEBHOOK_SECRET:
        return err("Webhook secret not configured.", 503)
    sig = request.headers.get("X-Razorpay-Signature", "")
    expected = hmac.new(RZP_WEBHOOK_SECRET.encode(), raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        return err("Bad signature.", 400)
    body = request.get_json(silent=True) or {}
    if body.get("event") == "qr_code.credited":
        payload = body.get("payload", {})
        qr_id = (payload.get("qr_code", {}).get("entity", {}) or {}).get("id")
        pay_id = (payload.get("payment", {}).get("entity", {}) or {}).get("id")
        with LOCK:
            advance()
            p = PAYMENTS.get(qr_id)
            if p:
                settle_payment(qr_id, p, pay_id)
    return jsonify({"ok": True})


# ---- history, stats, receipts ----
def _my_history():
    return [r for r in HISTORY if r.get("user") == g.user["id"]]


def _public_history():
    return [{k: v for k, v in r.items() if not k.startswith("_") and k != "user"}
            for r in reversed(_my_history())]


@app.get("/api/history")
@login_required
def api_history():
    with LOCK:
        return jsonify({"items": _public_history()})


@app.get("/api/stats")
@login_required
def api_stats():
    with LOCK:
        mine = _my_history()
        total = sum(r.get("total", 0) for r in mine)
        kwh = sum(r.get("energy_kwh", 0) for r in mine)
        km = kwh * 6.0                       # ~6 km per kWh (typical small EV)
        co2 = km * 0.09                      # rough kg CO2 avoided vs a petrol car
        avg = total / len(mine) if mine else 0.0
        by_station = {}
        for r in mine:
            by_station[r.get("station", "?")] = by_station.get(r.get("station", "?"), 0) + 1
        top = max(by_station.items(), key=lambda kv: kv[1])[0] if by_station else None
        return jsonify({
            "sessions": len(mine), "spent": round(total, 2), "kwh": round(kwh, 2),
            "km": round(km), "co2": round(co2, 1), "avg": round(avg, 2),
            "top_station": top,
        })


@app.get("/receipt/<invoice>")
def receipt_page(invoice):
    user = auth.current_user()
    if not user:
        abort(401)
    with LOCK:
        rec = next((r for r in HISTORY if r.get("invoice") == invoice and r.get("user") == user["id"]), None)
    if not rec:
        abort(404)
    e = html.escape

    def rupee(x):
        return f"\u20b9{x:,.2f}"

    rows = [
        (f"Electricity &middot; {rec['energy_kwh']:.2f} kWh &times; \u20b9{ELECTRICITY_RATE:g}", rec["electricity_cost"]),
        (f"Charging time &middot; {rec['charge_minutes']} min &times; \u20b9{CHARGING_RATE:g}", rec["charging_cost"]),
        (f"Idle time &middot; {rec['idle_minutes']} min &times; \u20b9{IDLE_RATE:g}", rec["idle_cost"]),
        ("Fixed station fee", rec["fixed_cost"]),
    ]
    body = "".join(f"<tr><td>{a}</td><td class='r'>{rupee(v)}</td></tr>" for a, v in rows)
    if rec.get("discount"):
        body += (f"<tr class='disc'><td>Promo {e(str(rec.get('promo') or ''))}</td>"
                 f"<td class='r'>&minus;{rupee(rec['discount'])}</td></tr>")
    if rec.get("fine_cost"):
        body += f"<tr><td>No-show fines</td><td class='r'>{rupee(rec['fine_cost'])}</td></tr>"
    pay_line = e(rec["method"]) + (f" &middot; {e(rec['payment_id'])}" if rec.get("payment_id") else "")
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(invoice)} - Invoice</title>
<style>
 body{{margin:0;background:#eef0ec;color:#1c2622;font-family:'Segoe UI',Roboto,Arial,sans-serif;padding:24px;font-size:15px}}
 .sheet{{max-width:600px;margin:0 auto;background:#fff;border:1px solid #cfd4cc;padding:30px 34px}}
 h1{{margin:0 0 2px;font-size:21px}} .muted{{color:#5d6a63;font-size:13px}}
 table{{width:100%;border-collapse:collapse;margin:18px 0 8px}} td{{padding:8px 0;border-bottom:1px solid #e3e6e0}}
 .r{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}} .disc td{{color:#1d6b4f}}
 .total td{{font-size:18px;font-weight:700;border-bottom:0;border-top:2px solid #1c2622;padding-top:12px}}
 .meta{{display:grid;grid-template-columns:1fr 1fr;gap:12px 20px;margin-top:18px;font-size:14px}}
 .meta b{{display:block;color:#5d6a63;font-weight:600;font-size:12px}}
 button{{margin-top:20px;background:#1d6b4f;color:#fff;border:0;border-radius:4px;padding:10px 18px;font-size:14px;cursor:pointer}}
 @media print{{body{{background:#fff;padding:0}} .sheet{{border:0}} button{{display:none}}}}
</style></head><body><div class="sheet">
<h1>EV Charging Station - Invoice</h1>
<div class="muted">{e(rec['invoice'])} &middot; {e(rec['date'])} &middot; {e(rec['txn'])}</div>
<div class="meta">
 <div><b>Station</b>{e(rec['station'])}</div><div><b>City</b>{e(rec['city'])}</div>
 <div><b>Address</b>{e(rec.get('address', '-'))}</div><div><b>Slot</b>{e(rec['slot'])} &middot; {e(rec['connector'])} &middot; {rec['power_kw']:g} kW</div>
 <div><b>Customer</b>{e(rec['customer'])}</div><div><b>Vehicle</b>{e(rec['vehicle'])}</div>
</div>
<table>{body}<tr class="total"><td>Total paid</td><td class="r">{rupee(rec['total'])}</td></tr></table>
<div class="muted">Paid via {pay_line}</div>
<button onclick="window.print()">Print / Save as PDF</button>
</div></body></html>"""
    return Response(page, mimetype="text/html")


# --------------------------------------------------------------------------
def main():
    port = int(os.getenv("PORT", "5050"))
    url = f"http://127.0.0.1:{port}"
    pay = "Razorpay " + ("TEST" if RZP_KEY_ID.startswith("rzp_test_") else "LIVE") if RZP_ENABLED else "demo"
    otp = "email/sms" if (auth.EMAIL_READY or auth.SMS_READY) else "demo (code printed here)"
    maps = "on" if GOOGLE_MAPS_KEY else "OFF - set GOOGLE_MAPS_API_KEY in .env"
    print(f"\n  {APP_NAME}\n  running at {url}\n"
          f"  payments: {pay} | otp delivery: {otp} | google maps: {maps}\n")
    if os.getenv("OPEN_BROWSER", "1") == "1":
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
