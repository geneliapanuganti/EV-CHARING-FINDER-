"""
OTP login.

The user types a mobile number or an email address, we send a 6 digit code and
they type it back. No passwords anywhere.

How the code gets delivered depends on what is configured in .env:
  * email  -> SMTP (SMTP_HOST, SMTP_USER, SMTP_PASSWORD ...)
  * mobile -> Twilio SMS (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM)
  * nothing configured -> "demo delivery": the code is printed in the terminal
    and also sent back to the browser so you can test without an SMS account.
    Set SHOW_DEV_OTP=0 to switch the on-screen code off.
"""

import hashlib
import hmac
import os
import re
import secrets
import smtplib
import threading
import time
import uuid
from datetime import datetime, timedelta
from email.message import EmailMessage
from functools import wraps

import requests
from flask import Blueprint, g, jsonify, request, session

from common import BASE_DIR, err, read_json, write_json

bp = Blueprint("auth", __name__, url_prefix="/api/auth")

USERS_FILE = os.path.join(BASE_DIR, "users.json")
SECRET_FILE = os.path.join(BASE_DIR, ".secret_key")

OTP_LIFETIME = 5 * 60      # seconds a code stays valid
RESEND_WAIT = 30           # seconds before another code can be requested
MAX_TRIES = 5              # wrong guesses allowed per code
MAX_SENDS_PER_HOUR = 5     # codes per mobile/email per hour

NO_SHOW_FINE = 100.0       # Rs charged when a booked slot is never started
MAX_NO_SHOWS = 5           # this many no-shows and the account is blocked

SMTP_HOST = os.getenv("SMTP_HOST", "").strip()
SMTP_PORT = int(os.getenv("SMTP_PORT", "587") or 587)
SMTP_USER = os.getenv("SMTP_USER", "").strip()
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "").strip()
SMTP_FROM = os.getenv("SMTP_FROM", "").strip() or SMTP_USER
TWILIO_SID = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
TWILIO_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
TWILIO_FROM = os.getenv("TWILIO_FROM", "").strip()
SHOW_DEV_OTP = os.getenv("SHOW_DEV_OTP", "1") == "1"

EMAIL_READY = bool(SMTP_HOST and SMTP_FROM)
SMS_READY = bool(TWILIO_SID and TWILIO_TOKEN and TWILIO_FROM)

_lock = threading.Lock()
_pending = {}   # identifier -> {"hash", "expires", "tries", "sent_at"}
_sent_log = {}  # identifier -> [timestamps of recent sends]
_users = read_json(USERS_FILE, {})


def get_secret_key():
    """Cookie signing key. Taken from .env, otherwise generated once and kept in a file."""
    key = os.getenv("SECRET_KEY", "").strip()
    if key:
        return key
    if os.path.exists(SECRET_FILE):
        with open(SECRET_FILE, "r", encoding="utf-8") as f:
            saved = f.read().strip()
        if saved:
            return saved
    key = secrets.token_hex(32)
    try:
        with open(SECRET_FILE, "w", encoding="utf-8") as f:
            f.write(key)
    except OSError:
        pass  # still works, but everyone gets logged out on restart
    return key


SECRET = get_secret_key()


# ---------------------------------------------------------------- identifiers
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")


def normalize(raw):
    """Return (kind, value). kind is 'email' or 'phone'. Raises ValueError with a user-facing message."""
    raw = (raw or "").strip()
    if not raw:
        raise ValueError("Enter your mobile number or email address.")
    if "@" in raw:
        if not EMAIL_RE.match(raw) or len(raw) > 120:
            raise ValueError("That email address doesn't look right.")
        return "email", raw.lower()
    digits = re.sub(r"\D", "", raw)
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    if len(digits) != 10 or digits[0] not in "6789":
        raise ValueError("Enter a valid 10 digit Indian mobile number, or an email address.")
    return "phone", "+91" + digits


def mask(kind, value):
    if kind == "email":
        name, domain = value.split("@", 1)
        return name[0] + "***@" + domain
    return value[:3] + " ******" + value[-4:]


def admin_set():
    out = set()
    for item in os.getenv("ADMIN_USERS", "").split(","):
        item = item.strip()
        if not item:
            continue
        try:
            out.add(normalize(item)[1])
        except ValueError:
            pass
    return out


ADMINS = admin_set()


# ---------------------------------------------------------------- delivery
def _hash(identifier, code):
    return hmac.new(SECRET.encode(), f"{identifier}:{code}".encode(), hashlib.sha256).hexdigest()


def _send_email(to, code):
    msg = EmailMessage()
    msg["Subject"] = "Your EV charging login code"
    msg["From"] = SMTP_FROM
    msg["To"] = to
    msg.set_content(
        f"Your one-time login code is {code}.\n\n"
        f"It is valid for {OTP_LIFETIME // 60} minutes. If you didn't ask for it, ignore this email."
    )
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=15) as server:
        server.starttls()
        if SMTP_USER:
            server.login(SMTP_USER, SMTP_PASSWORD)
        server.send_message(msg)


def _send_sms(to, code):
    r = requests.post(
        f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_SID}/Messages.json",
        auth=(TWILIO_SID, TWILIO_TOKEN),
        data={"To": to, "From": TWILIO_FROM,
              "Body": f"{code} is your EV charging login code. Valid for {OTP_LIFETIME // 60} minutes."},
        timeout=15,
    )
    if r.status_code >= 400:
        try:
            detail = r.json().get("message", "")
        except ValueError:
            detail = ""
        raise RuntimeError(detail or f"SMS provider error {r.status_code}")


def deliver(kind, value, code):
    """Returns 'email', 'sms' or 'demo'."""
    if kind == "email" and EMAIL_READY:
        _send_email(value, code)
        return "email"
    if kind == "phone" and SMS_READY:
        _send_sms(value, code)
        return "sms"
    print(f"\n  [demo otp] code for {value}: {code}\n", flush=True)
    return "demo"


# ---------------------------------------------------------------- users
def save_users():
    write_json(USERS_FILE, _users)


def find_or_create_user(kind, value):
    with _lock:
        for u in _users.values():
            if u["identifier"] == value:
                return u, False
        uid = "u" + uuid.uuid4().hex[:8]
        user = {"id": uid, "identifier": value, "kind": kind, "name": "",
                "created": datetime.now().strftime("%Y-%m-%d %H:%M")}
        _users[uid] = user
        save_users()
        return user, True


# ---------------------------------------------------------------- no-show fines
def account_status(u):
    """Fine / block information the front end shows to the driver."""
    strikes = int(u.get("no_shows", 0))
    return {
        "strikes": strikes,
        "max_strikes": MAX_NO_SHOWS,
        "fine_amount": NO_SHOW_FINE,
        "fine_pending": round(float(u.get("fine_pending", 0.0)), 2),
        "fine_total": round(float(u.get("fine_total", 0.0)), 2),
        "blocked": bool(u.get("blocked", False)),
        "fines": list(u.get("fine_log", []))[-10:][::-1],
    }


def is_blocked(uid):
    u = _users.get(uid)
    return bool(u and u.get("blocked"))


def add_no_show(uid, station_name, slot_label, when):
    """Record one missed booking: Rs 100 fine, and block the account on the 5th.
    Returns the updated account_status (or None if the user no longer exists)."""
    with _lock:
        u = _users.get(uid)
        if not u:
            return None
        u["no_shows"] = int(u.get("no_shows", 0)) + 1
        u["fine_pending"] = round(float(u.get("fine_pending", 0.0)) + NO_SHOW_FINE, 2)
        u["fine_total"] = round(float(u.get("fine_total", 0.0)) + NO_SHOW_FINE, 2)
        log = u.setdefault("fine_log", [])
        log.append({"date": datetime.now().strftime("%Y-%m-%d %H:%M"), "station": station_name,
                    "slot": slot_label, "amount": NO_SHOW_FINE, "strike": u["no_shows"]})
        del log[:-50]
        if u["no_shows"] >= MAX_NO_SHOWS:
            u["blocked"] = True
        save_users()
        return account_status(u)


def pending_fine(uid):
    u = _users.get(uid)
    return round(float(u.get("fine_pending", 0.0)), 2) if u else 0.0


def settle_fine(uid, amount):
    """The driver paid `amount` of fines together with a bill."""
    if amount <= 0:
        return
    with _lock:
        u = _users.get(uid)
        if not u:
            return
        u["fine_pending"] = round(max(0.0, float(u.get("fine_pending", 0.0)) - amount), 2)
        save_users()


def user_public(u):
    return {"id": u["id"], "name": u["name"], "identifier": u["identifier"],
            "shown": mask(u["kind"], u["identifier"]), "is_admin": u["identifier"] in ADMINS,
            "account": account_status(u)}


def current_user():
    uid = session.get("uid")
    return _users.get(uid) if uid else None


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()
        if not user:
            return err("Please log in first.", 401)
        g.user = user
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapper(*args, **kwargs):
        if g.user["identifier"] not in ADMINS:
            return err("Only station staff can do that.", 403)
        return fn(*args, **kwargs)
    return wrapper


# ---------------------------------------------------------------- routes
@bp.post("/request-otp")
def request_otp():
    body = request.get_json(silent=True) or {}
    try:
        kind, value = normalize(body.get("identifier"))
    except ValueError as e:
        return err(str(e))

    now = time.time()
    with _lock:
        old = _pending.get(value)
        if old and now - old["sent_at"] < RESEND_WAIT:
            wait = int(RESEND_WAIT - (now - old["sent_at"])) + 1
            return err(f"Please wait {wait} seconds before asking for another code.", 429)
        recent = [t for t in _sent_log.get(value, []) if now - t < 3600]
        if len(recent) >= MAX_SENDS_PER_HOUR:
            return err("Too many codes requested. Try again in an hour.", 429)
        code = f"{secrets.randbelow(1_000_000):06d}"
        _pending[value] = {"hash": _hash(value, code), "expires": now + OTP_LIFETIME,
                           "tries": 0, "sent_at": now}
        recent.append(now)
        _sent_log[value] = recent

    try:
        channel = deliver(kind, value, code)
    except Exception as exc:  # smtp / network / provider problems
        with _lock:
            _pending.pop(value, None)
        return err(f"Couldn't send the code: {exc}", 502)

    out = {"sent": True, "channel": channel, "to": mask(kind, value),
           "identifier": value, "expires_in": OTP_LIFETIME, "resend_in": RESEND_WAIT}
    if channel == "demo" and SHOW_DEV_OTP:
        out["dev_otp"] = code
    return jsonify(out)


@bp.post("/verify-otp")
def verify_otp():
    body = request.get_json(silent=True) or {}
    try:
        kind, value = normalize(body.get("identifier"))
    except ValueError as e:
        return err(str(e))
    code = re.sub(r"\D", "", str(body.get("otp", "")))
    if len(code) != 6:
        return err("Enter the 6 digit code.")

    with _lock:
        p = _pending.get(value)
        if not p:
            return err("Request a code first.", 400)
        if time.time() > p["expires"]:
            _pending.pop(value, None)
            return err("That code has expired. Request a new one.", 400)
        if p["tries"] >= MAX_TRIES:
            _pending.pop(value, None)
            return err("Too many wrong attempts. Request a new code.", 429)
        if not hmac.compare_digest(p["hash"], _hash(value, code)):
            p["tries"] += 1
            left = MAX_TRIES - p["tries"]
            return err(f"Wrong code. {left} attempt{'s' if left != 1 else ''} left.", 400)
        _pending.pop(value, None)

    user, is_new = find_or_create_user(kind, value)
    session.clear()
    session["uid"] = user["id"]
    session.permanent = True
    return jsonify({"user": user_public(user), "needs_name": not user["name"], "new": is_new})


@bp.post("/profile")
@login_required
def save_profile():
    name = re.sub(r"\s+", " ", str((request.get_json(silent=True) or {}).get("name", ""))).strip()
    if len(name) < 2 or len(name) > 40:
        return err("Enter your name (2 to 40 characters).")
    with _lock:
        g.user["name"] = name
        save_users()
    return jsonify({"user": user_public(g.user)})


@bp.get("/me")
def me():
    user = current_user()
    if not user:
        return err("Not logged in.", 401)
    return jsonify({"user": user_public(user), "needs_name": not user["name"]})


@bp.post("/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


def configure(app):
    app.secret_key = SECRET
    app.permanent_session_lifetime = timedelta(days=7)
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    app.register_blueprint(bp)
