"""
Issue tracking.

Drivers report problems at a station (charger dead, cable damaged, wrong bill ...).
Each report becomes a ticket with a status and a small activity log. Station staff
(the logins listed in ADMIN_USERS in .env) can see every ticket and move it
through Open -> In progress -> Resolved. Drivers can add comments and close
their own tickets.
"""

import os
import threading
from datetime import datetime

from flask import Blueprint, g, jsonify, request

from auth import ADMINS, login_required
from common import BASE_DIR, err, read_json, write_json

bp = Blueprint("issues", __name__, url_prefix="/api/issues")

ISSUES_FILE = os.path.join(BASE_DIR, "issues.json")

CATEGORIES = {
    "charger_fault": "Charger not working",
    "connector": "Connector or cable damaged",
    "slot_blocked": "Slot blocked by another vehicle",
    "payment": "Payment problem",
    "billing": "Billing or invoice dispute",
    "safety": "Safety concern",
    "other": "Something else",
}
PRIORITIES = ["low", "medium", "high"]
STATUSES = ["open", "in_progress", "resolved", "closed"]
STATUS_LABEL = {"open": "Open", "in_progress": "In progress", "resolved": "Resolved", "closed": "Closed"}
MAX_OPEN_PER_USER = 10

_lock = threading.RLock()
_issues = read_json(ISSUES_FILE, [])
_stations = {}   # filled in by app.py -> station id -> Station object


def init(stations):
    _stations.update(stations)


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def _save():
    write_json(ISSUES_FILE, _issues)


def _is_admin():
    return g.user["identifier"] in ADMINS


def _can_see(issue):
    return _is_admin() or issue["user"] == g.user["id"]


def _public(issue, full=False):
    out = {k: v for k, v in issue.items() if k not in ("user", "updates")}
    out["category_label"] = CATEGORIES.get(issue["category"], issue["category"])
    out["status_label"] = STATUS_LABEL[issue["status"]]
    out["mine"] = issue["user"] == g.user["id"]
    out["update_count"] = len(issue["updates"])
    if full:
        out["updates"] = issue["updates"]
    return out


def _find(issue_id):
    return next((i for i in _issues if i["id"] == issue_id), None)


def _log(issue, by, role, text, status=None):
    issue["updates"].append({"at": _now(), "by": by, "role": role, "text": text, "status": status})
    issue["updated"] = _now()


@bp.get("")
@login_required
def list_issues():
    scope = request.args.get("scope", "mine")
    with _lock:
        if scope == "all" and _is_admin():
            rows = list(_issues)
        else:
            rows = [i for i in _issues if i["user"] == g.user["id"]]
        rows.sort(key=lambda i: i["updated"], reverse=True)
        counts = {s: 0 for s in STATUSES}
        for i in rows:
            counts[i["status"]] += 1
        return jsonify({"items": [_public(i) for i in rows], "counts": counts,
                        "scope": "all" if (scope == "all" and _is_admin()) else "mine"})


@bp.get("/meta")
@login_required
def meta():
    return jsonify({"categories": CATEGORIES, "priorities": PRIORITIES,
                    "statuses": STATUS_LABEL})


@bp.post("")
@login_required
def create_issue():
    d = request.get_json(silent=True) or {}
    stn = _stations.get(d.get("station_id"))
    if not stn:
        return err("Choose the station the problem is at.")
    category = d.get("category")
    if category not in CATEGORIES:
        return err("Choose what kind of problem it is.")
    priority = d.get("priority", "medium")
    if priority not in PRIORITIES:
        return err("Invalid priority.")
    title = " ".join(str(d.get("title", "")).split())
    desc = str(d.get("description", "")).strip()
    if not (4 <= len(title) <= 80):
        return err("Give the issue a short title (4 to 80 characters).")
    if not (10 <= len(desc) <= 1000):
        return err("Describe what happened in 10 to 1000 characters.")
    slot = str(d.get("slot") or "")[:20]
    if slot and slot not in [s.label for s in stn.slots]:
        slot = ""

    with _lock:
        mine_open = sum(1 for i in _issues if i["user"] == g.user["id"] and i["status"] in ("open", "in_progress"))
        if mine_open >= MAX_OPEN_PER_USER:
            return err("You already have several open issues. Wait for them to be resolved first.", 429)
        n = max([int(i["id"].split("-")[1]) for i in _issues] or [0]) + 1
        issue = {
            "id": f"ISS-{n:04d}", "user": g.user["id"], "reporter": g.user["name"] or "Driver",
            "station_id": stn.id, "station": stn.name, "city": stn.city, "slot": slot,
            "category": category, "priority": priority, "title": title, "description": desc,
            "status": "open", "created": _now(), "updated": _now(), "updates": [],
        }
        _log(issue, issue["reporter"], "driver", "Issue reported.", "open")
        _issues.append(issue)
        _save()
        return jsonify({"issue": _public(issue, full=True)}), 201


@bp.get("/<issue_id>")
@login_required
def get_issue(issue_id):
    with _lock:
        issue = _find(issue_id)
        if not issue or not _can_see(issue):
            return err("Issue not found.", 404)
        return jsonify({"issue": _public(issue, full=True)})


@bp.post("/<issue_id>/comment")
@login_required
def comment(issue_id):
    text = str((request.get_json(silent=True) or {}).get("text", "")).strip()
    if not (2 <= len(text) <= 600):
        return err("Write a comment between 2 and 600 characters.")
    with _lock:
        issue = _find(issue_id)
        if not issue or not _can_see(issue):
            return err("Issue not found.", 404)
        if issue["status"] == "closed":
            return err("This issue is closed. Reopen it to add a comment.")
        staff = _is_admin() and issue["user"] != g.user["id"]
        _log(issue, g.user["name"] or ("Staff" if staff else "Driver"), "staff" if staff else "driver", text)
        _save()
        return jsonify({"issue": _public(issue, full=True)})


@bp.post("/<issue_id>/status")
@login_required
def change_status(issue_id):
    d = request.get_json(silent=True) or {}
    new = d.get("status")
    note = str(d.get("note", "")).strip()[:600]
    if new not in STATUSES:
        return err("Unknown status.")
    with _lock:
        issue = _find(issue_id)
        if not issue or not _can_see(issue):
            return err("Issue not found.", 404)
        owner = issue["user"] == g.user["id"]
        if not _is_admin():
            # drivers can only close their own ticket, or reopen one that was resolved/closed
            allowed = (new == "closed" and issue["status"] != "closed") or \
                      (new == "open" and issue["status"] in ("resolved", "closed"))
            if not (owner and allowed):
                return err("You can't change the status that way.", 403)
        if new == issue["status"]:
            return err("The issue is already " + STATUS_LABEL[new].lower() + ".")
        issue["status"] = new
        role = "staff" if (_is_admin() and not owner) else "driver"
        _log(issue, g.user["name"] or role.title(), role,
             note or f"Status changed to {STATUS_LABEL[new]}.", new)
        _save()
        return jsonify({"issue": _public(issue, full=True)})
