"""Small helpers shared by app.py, auth.py and issues.py."""

import json
import os
import tempfile

from flask import jsonify

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def load_env(path=os.path.join(BASE_DIR, ".env")):
    """Read KEY=value lines from .env into os.environ (no python-dotenv needed)."""
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


# has to run before any other module reads os.environ
load_env()


def err(message, code=400):
    return jsonify({"error": message}), code


def read_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        # don't silently throw away a damaged file, keep a copy next to it
        try:
            os.replace(path, path + ".corrupt.bak")
        except OSError:
            pass
        return default


def write_json(path, data):
    """Write to a temp file first so a crash can't leave half a file behind."""
    try:
        fd, tmp = tempfile.mkstemp(dir=BASE_DIR, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, path)
        return True
    except OSError:
        return False
