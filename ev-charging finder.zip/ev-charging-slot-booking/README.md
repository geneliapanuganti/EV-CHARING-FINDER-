# Electric Vehicle Charging Station Slot Booking & Issue Tracking App

A web app for finding an EV charging station, booking a slot, paying for the charge and reporting problems at a station.
Backend is Python (Flask), front end is plain HTML, CSS and JavaScript. There is no build step.

## What it does

* **OTP login** with a mobile number or an email address (no passwords).
* **Stations on Google Maps**: 24 stations in 6 cities with live free/busy slots, search, filters, "use my location" and directions.
* **Slot booking**: pick a slot, enter your vehicle and battery level, and the slot is held for 15 minutes.
* **Charging**: live battery progress, charging and idle timers, running bill, pause and unplug.
* **Payments**: UPI QR through Razorpay (or a built in demo QR), cash at the counter, promo codes and printable invoices.
* **Issue tracking**: report a problem at a station (charger fault, damaged cable, billing dispute ...). Each report gets an ID
  such as `ISS-0001`, a status (Open, In progress, Resolved, Closed) and an activity log. Station staff can see every report and update it.

* **No-show fines**: if you book a slot and don't start charging within 15 minutes, the booking expires and a **Rs 100 fine** is added to your next bill.
  After **5 no-shows the account is blocked** from new bookings (charging already in progress can still be finished and paid).
  Cancelling before the 15 minutes are up is free and doesn't count. The counts are saved in `users.json` (`no_shows`, `fine_pending`, `blocked`);
  to reopen an account, set `"blocked": false` and `"no_shows": 0` for that user and restart. Change `NO_SHOW_FINE` / `MAX_NO_SHOWS` at the top of `auth.py`.

Billing is unchanged: Rs 60 per kWh + Rs 2 per minute of charging + Rs 5 per minute idle + Rs 20 fixed fee.

## Run it

1. Install Python 3.9 or newer.
2. In this folder:

   ```
   python -m venv .venv
   .venv\Scripts\activate          (Windows)
   source .venv/bin/activate       (macOS / Linux)

   pip install -r requirements.txt
   copy .env.example .env          (Windows)    cp .env.example .env   (macOS / Linux)
   python app.py
   ```
3. Open http://127.0.0.1:5050 (it opens by itself). In VS Code you can also press F5.

The app works straight away. Without any keys the map shows a notice, OTP codes are shown on the login page, and payments use the demo QR.

## 1. Google Maps

1. Open the [Google Cloud Console](https://console.cloud.google.com/), create or pick a project and **enable billing** (Google gives a monthly free credit, light use costs nothing).
2. *APIs & Services > Library* > enable **Maps JavaScript API**.
3. *APIs & Services > Credentials > Create credentials > API key*.
4. Restrict the key: *Application restrictions > Websites* and add `http://127.0.0.1:5050/*` and `http://localhost:5050/*` (add your real domain when you deploy). Under *API restrictions* choose Maps JavaScript API.
5. Put the key in `.env`:

   ```
   GOOGLE_MAPS_API_KEY=your_key_here
   ```
6. Restart `python app.py`.

The map uses Google's `DEMO_MAP_ID`. For your own styling, create a Map ID under *Google Maps Platform > Map Management* and set `GOOGLE_MAP_ID`.
"Directions" buttons open Google Maps in a new tab, so they need no extra API.

## 2. OTP login

The user enters a mobile number (10 digit Indian number) or an email address, receives a 6 digit code valid for 5 minutes, and types it in.
A code allows 5 wrong attempts, can be resent after 30 seconds, and each number or email can request 5 codes per hour. Codes are never stored in plain text.

| Setting in `.env` | What happens |
|---|---|
| nothing filled in | **Demo delivery.** The code is printed in the terminal and shown on the login page. Good for local testing. Set `SHOW_DEV_OTP=0` to hide it on the page. |
| `SMTP_HOST`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` | Codes for **email** logins are sent by email. For Gmail use `smtp.gmail.com`, port 587 and an [App Password](https://myaccount.google.com/apppasswords). |
| `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM` | Codes for **mobile** logins are sent by SMS through Twilio. |

Email and SMS are independent, so you can configure only one of them. Turn `SHOW_DEV_OTP` off before putting the app on the internet.

On first login the app asks for your name. Accounts are kept in `users.json`.

## 3. Issue tracking and station staff

Any logged in user can report an issue from the **Issues** tab, from a station's detail panel, or from a booking ("Report a problem").
Drivers see only their own reports, can add comments, close an issue, or reopen one that was resolved.

To give someone the staff view, add their mobile number or email to `ADMIN_USERS` in `.env` (comma separated) and restart:

```
ADMIN_USERS=9876543210,manager@example.com
```

Staff get an extra **All reports** switch on the Issues tab and can change the status of any report and reply to the driver.
Reports are stored in `issues.json`.

## 4. Razorpay payments (optional)

Leave the keys empty to use the demo QR with a "Simulate payment" button. For real UPI QR payments put your Razorpay keys in `.env`:

```
RAZORPAY_KEY_ID=rzp_test_xxxxxxxx
RAZORPAY_KEY_SECRET=xxxxxxxx
```

Test keys cannot be paid from a real UPI app; simulate the payment from the Razorpay dashboard (Test mode > QR Codes).
Promo codes to try: `SAVE10`, `FIRSTCHARGE`, `EV25`.

## Demo timer

Real charging takes hours, so the *My bookings* page has a **Demo timer speed** setting. At 60x one real second counts as one minute.

## Files

```
app.py            main Flask app: stations, bookings, billing, payments, receipts
auth.py           OTP login, users, sessions
issues.py         issue tracking
common.py         .env loading and JSON file helpers
static/           index.html, style.css, app.js
.env.example      copy to .env and fill in
```

Created while running: `users.json`, `issues.json`, `ev_billing_history.json`, `receipts/`, `.secret_key` (all ignored by git).

## Notes

* Station names and addresses are sample data. Edit the `CITIES` dictionary in `app.py` to add your own.
* Active bookings are kept in memory, so restarting the server clears them. Users, issues and paid history are saved to disk.
* This is built for a single server process. For a real deployment run it behind a proper WSGI server (for example gunicorn) over HTTPS.
